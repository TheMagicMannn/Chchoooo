import React from "react";
import { Link, useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { BarChart2, ShieldAlert, BellRing, Plug2, Settings, CreditCard, Building2, FileText, FileBarChart2, User } from "lucide-react";
import { useState } from "react";

const navItems = [
  { href: "/connect", label: "Overview", icon: BarChart2 },
  { href: "/risk", label: "Risk & Detection", icon: ShieldAlert },
  { href: "/alerts", label: "Fraud Alerts", icon: BellRing },
  { href: "/integrations", label: "Integrations", icon: Plug2 },
  { href: "/settings", label: "Settings", icon: Settings },
  { href: "/billing", label: "Billing", icon: CreditCard },
  { href: "/logs", label: "Log Explorer", icon: FileText },
  { href: "/reports", label: "Reports", icon: FileBarChart2 },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <Layout>
      <div className="flex w-full h-full min-h-[calc(100vh-3.5rem)]">
        <aside className="w-56 border-r border-border bg-card/30 flex-shrink-0 hidden md:flex flex-col sticky top-14 h-[calc(100vh-3.5rem)] overflow-y-auto">
          <div className="text-xs uppercase text-muted-foreground/60 tracking-widest px-4 py-3 font-semibold mt-2">
            App
          </div>
          <nav className="flex-1 px-2 space-y-1 pb-4">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <div
                  className={`flex items-center gap-2.5 text-sm px-3 py-2 rounded-md transition-colors cursor-pointer ${
                    location === item.href
                      ? "bg-primary/10 text-primary font-medium"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </div>
              </Link>
            ))}
            
            <div className="my-4 border-t border-border/50 mx-2"></div>
            
            <Link href="/enterprise">
              <div
                className={`flex items-center gap-2.5 text-sm px-3 py-2 rounded-md transition-colors cursor-pointer ${
                  location === "/enterprise"
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <Building2 className="h-4 w-4" />
                Enterprise
              </div>
            </Link>

            <div className="my-4 border-t border-border/50 mx-2"></div>
            
            <Link href="/profile">
              <div
                className={`flex items-center gap-2.5 text-sm px-3 py-2 rounded-md transition-colors cursor-pointer ${
                  location === "/profile"
                    ? "bg-primary/10 text-primary font-medium"
                    : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                }`}
              >
                <User className="h-4 w-4" />
                Profile
              </div>
            </Link>
            <div className="px-4 text-xs text-muted-foreground/60 truncate">
              {useState(() => { try { const u = JSON.parse(localStorage.getItem('poh_user') || '{}'); return u.name || 'Account'; } catch(e) { return 'Account'; } })[0]}
            </div>
          </nav>
        </aside>
        <main className="flex-1 overflow-auto bg-background/50 relative">
          {children}
        </main>
      </div>
    </Layout>
  );
}
