import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "@/components/theme-provider";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Architecture from "@/pages/architecture";
import Docs from "@/pages/docs";
import Dashboard from "@/pages/dashboard";
import Ops from "@/pages/ops";
import Playbooks from "@/pages/playbooks";
import Onboarding from "@/pages/onboarding";
import Connect from "@/pages/connect";

import Risk from "@/pages/risk";
import Alerts from "@/pages/alerts";
import Integrations from "@/pages/integrations";
import SettingsPage from "@/pages/settings";
import Billing from "@/pages/billing";
import Enterprise from "@/pages/enterprise";
import Logs from "@/pages/logs";
import Reports from "@/pages/reports";
import Login from "@/pages/login";
import Profile from "@/pages/profile";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/architecture" component={Architecture} />
      <Route path="/docs" component={Docs} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/ops" component={Ops} />
      <Route path="/playbooks" component={Playbooks} />
      <Route path="/deployment" component={Docs} /> {/* Maps to Docs section for simplicity */}
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/connect" component={Connect} />
      <Route path="/risk" component={Risk} />
      <Route path="/alerts" component={Alerts} />
      <Route path="/integrations" component={Integrations} />
      <Route path="/settings" component={SettingsPage} />
      <Route path="/billing" component={Billing} />
      <Route path="/enterprise" component={Enterprise} />
      <Route path="/logs" component={Logs} />
      <Route path="/reports" component={Reports} />
      <Route path="/login" component={Login} />
      <Route path="/profile" component={Profile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <QueryClientProvider client={queryClient}>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
