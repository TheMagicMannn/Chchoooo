import { useState } from 'react';
import { AppLayout } from '@/components/app-layout';
import { FileBarChart2, Download, Plus, Calendar, Check, Clock } from 'lucide-react';

const SAVED_REPORTS = [
  { id:1, name:'January 2024 — Bot Traffic Summary', dateRange:'Jan 1–31, 2024', domain:'yourstore.com', generated:'Feb 1, 2024', format:'CSV', rows:14823 },
  { id:2, name:'Q4 2023 — Checkout Protection Analysis', dateRange:'Oct–Dec 2023', domain:'All Domains', generated:'Jan 2, 2024', format:'PDF', rows:52411 },
  { id:3, name:'Weekly Digest — Jan 8–14', dateRange:'Jan 8–14, 2024', domain:'client-demo.com', generated:'Jan 15, 2024', format:'CSV', rows:3249 },
  { id:4, name:'GA4 Enrichment Audit — December', dateRange:'Dec 1–31, 2023', domain:'yourstore.com', generated:'Jan 1, 2024', format:'PDF', rows:18932 },
  { id:5, name:'Bot Cluster Report — Cluster A', dateRange:'Jan 1–15, 2024', domain:'All Domains', generated:'Jan 16, 2024', format:'CSV', rows:412 },
];
const METRICS_OPTIONS = ['Total Sessions','Human Rate %','Bot Rate %','Avg Risk Score','Bots Blocked','CAPTCHA Triggers','Geographic Breakdown','Event Type Breakdown'];
const PREVIEW_DATA = [
  {date:'Jan 1',sessions:521,human:462,bot:59,humanRate:'88.7%',avgScore:0.89,blocked:59},
  {date:'Jan 2',sessions:487,human:431,bot:56,humanRate:'88.5%',avgScore:0.91,blocked:56},
  {date:'Jan 3',sessions:612,human:541,bot:71,humanRate:'88.4%',avgScore:0.88,blocked:71},
  {date:'Jan 4',sessions:448,human:398,bot:50,humanRate:'88.8%',avgScore:0.90,blocked:50},
  {date:'Jan 5',sessions:534,human:472,bot:62,humanRate:'88.4%',avgScore:0.87,blocked:62},
  {date:'Jan 6',sessions:390,human:347,bot:43,humanRate:'88.9%',avgScore:0.92,blocked:43},
  {date:'Jan 7',sessions:421,human:374,bot:47,humanRate:'88.8%',avgScore:0.91,blocked:47},
  {date:'Jan 8',sessions:589,human:521,bot:68,humanRate:'88.4%',avgScore:0.89,blocked:68},
  {date:'Jan 9',sessions:631,human:558,bot:73,humanRate:'88.4%',avgScore:0.88,blocked:73},
  {date:'Jan 10',sessions:501,human:444,bot:57,humanRate:'88.6%',avgScore:0.90,blocked:57},
];

export default function Reports() {
  const [activeTab, setActiveTab] = useState<'saved'|'create'|'preview'>('saved');
  const [reportName, setReportName] = useState('');
  const [selectedDomains, setSelectedDomains] = useState<string[]>(['yourstore.com']);
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>(['Total Sessions','Human Rate %','Bot Rate %']);
  const [reportFormat, setReportFormat] = useState<'CSV'|'PDF'>('CSV');
  const [reportSchedule, setReportSchedule] = useState<'once'|'weekly'|'monthly'>('once');
  const [exportedId, setExportedId] = useState<number|null>(null);
  const [estRows] = useState(() => Math.floor(Math.random()*5000+1000));

  const handleExport = (id: number) => {
    setExportedId(id);
    setTimeout(() => setExportedId(null), 1500);
  };

  const toggleDomain = (d: string) => {
    setSelectedDomains(prev => prev.includes(d) ? prev.filter(x => x !== d) : [...prev, d]);
  };

  const toggleMetric = (m: string) => {
    setSelectedMetrics(prev => prev.includes(m) ? prev.filter(x => x !== m) : [...prev, m]);
  };

  return (
    <AppLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Reports</h1>
            <p className="text-muted-foreground text-sm">Saved and scheduled analytics exports</p>
          </div>
          <button 
            onClick={() => setActiveTab('create')}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" /> New Report
          </button>
        </div>

        <div className="flex space-x-2 border-b border-border/40 mb-6">
          {(['saved', 'create', 'preview'] as const).map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors capitalize ${
                activeTab === t
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t === 'saved' ? 'Saved Reports' : t === 'create' ? 'Create Report' : 'Preview'}
            </button>
          ))}
        </div>

        {activeTab === 'saved' && (
          <div className="space-y-8">
            <div className="space-y-3">
              {SAVED_REPORTS.map(report => (
                <div key={report.id} className="bg-card border border-border rounded-xl p-5 flex items-center justify-between gap-4 shadow-sm hover:border-primary/30 transition-colors">
                  <FileBarChart2 className="text-primary w-8 h-8 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm">{report.name}</div>
                    <div className="text-xs text-muted-foreground truncate">{report.dateRange} | {report.domain}</div>
                    <div className="text-xs text-muted-foreground/60 mt-0.5">Generated: {report.generated}</div>
                  </div>
                  <div className="flex items-center gap-4 shrink-0">
                    <div className="text-xs text-muted-foreground hidden sm:block">{report.rows.toLocaleString()} rows</div>
                    <div className={`text-xs px-2 py-0.5 rounded font-medium ${
                      report.format === 'CSV' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'
                    }`}>
                      {report.format}
                    </div>
                    <button 
                      onClick={() => setActiveTab('preview')}
                      className="px-3 py-1.5 border border-border rounded-md text-xs font-medium hover:bg-secondary transition-colors"
                    >
                      Preview
                    </button>
                    <button 
                      onClick={() => handleExport(report.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary hover:bg-secondary/80 rounded-md text-xs font-medium transition-colors w-24 justify-center"
                    >
                      {exportedId === report.id ? (
                        <><Check className="w-3.5 h-3.5 text-green-500" /> <span className="text-green-500">Exported!</span></>
                      ) : (
                        <><Download className="w-3.5 h-3.5" /> Export</>
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div>
              <h3 className="font-semibold text-lg mb-4">Scheduled Reports</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-card border border-border rounded-xl p-5 flex items-center justify-between gap-4 shadow-sm">
                  <Clock className="text-primary w-8 h-8 shrink-0" />
                  <div className="flex-1">
                    <div className="font-medium text-sm">Weekly Digest</div>
                    <div className="text-xs text-muted-foreground">Every Monday 9:00 UTC | yourstore.com</div>
                    <div className="text-xs text-muted-foreground/60 mt-0.5">Next: Jan 22, 2024</div>
                  </div>
                </div>
                <div className="bg-card border border-border rounded-xl p-5 flex items-center justify-between gap-4 shadow-sm">
                  <Clock className="text-primary w-8 h-8 shrink-0" />
                  <div className="flex-1">
                    <div className="font-medium text-sm">Monthly Summary</div>
                    <div className="text-xs text-muted-foreground">1st of month 00:00 UTC | All Domains</div>
                    <div className="text-xs text-muted-foreground/60 mt-0.5">Next: Feb 1, 2024</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'create' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-in fade-in">
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1.5">Report Name</label>
                <input 
                  type="text" 
                  value={reportName}
                  onChange={e => setReportName(e.target.value)}
                  placeholder="e.g. Q1 Bot Analysis"
                  className="w-full bg-secondary border border-border rounded-md px-3 py-2 text-sm outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1.5">Date Range</label>
                <div className="flex gap-2">
                  <div className="flex-1 bg-secondary border border-border rounded-md px-3 py-2 text-sm flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" /> From: Jan 1, 2024
                  </div>
                  <div className="flex-1 bg-secondary border border-border rounded-md px-3 py-2 text-sm flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-muted-foreground" /> To: Jan 31, 2024
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Domains</label>
                <div className="space-y-2">
                  {['All Domains', 'yourstore.com', 'client-demo.com'].map(d => (
                    <label key={d} className="flex items-center gap-2 text-sm cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={selectedDomains.includes(d)}
                        onChange={() => toggleDomain(d)}
                        className="rounded border-border bg-background"
                      /> {d}
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Metrics</label>
                <div className="grid grid-cols-2 gap-2">
                  {METRICS_OPTIONS.map(m => (
                    <label key={m} className="flex items-center gap-2 text-sm cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={selectedMetrics.includes(m)}
                        onChange={() => toggleMetric(m)}
                        className="rounded border-border bg-background"
                      /> {m}
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Format</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={reportFormat === 'CSV'} onChange={() => setReportFormat('CSV')} /> CSV
                  </label>
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={reportFormat === 'PDF'} onChange={() => setReportFormat('PDF')} /> PDF
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-2">Schedule</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={reportSchedule === 'once'} onChange={() => setReportSchedule('once')} /> One-time
                  </label>
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={reportSchedule === 'weekly'} onChange={() => setReportSchedule('weekly')} /> Weekly
                  </label>
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={reportSchedule === 'monthly'} onChange={() => setReportSchedule('monthly')} /> Monthly
                  </label>
                </div>
              </div>

              <button 
                onClick={() => setActiveTab('preview')}
                className="w-full bg-primary text-primary-foreground py-2.5 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors"
              >
                Generate Report
              </button>
            </div>

            <div>
              <div className="bg-card border border-border rounded-xl p-5 sticky top-6 shadow-sm">
                <h3 className="font-semibold text-lg mb-4">Configuration Preview</h3>
                <ul className="space-y-3 text-sm">
                  <li className="flex gap-2">
                    <span className="text-muted-foreground w-20">Name:</span> 
                    <span className="font-medium text-foreground">{reportName || 'Untitled Report'}</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-muted-foreground w-20">Domains:</span> 
                    <span>{selectedDomains.join(', ') || 'None selected'}</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-muted-foreground w-20 shrink-0">Metrics:</span> 
                    <div className="flex flex-wrap gap-1">
                      {selectedMetrics.map(m => (
                        <span key={m} className="bg-secondary px-2 py-0.5 rounded text-xs">{m}</span>
                      ))}
                      {selectedMetrics.length === 0 && 'None selected'}
                    </div>
                  </li>
                  <li className="flex gap-2 items-center">
                    <span className="text-muted-foreground w-20">Format:</span> 
                    <span className={`text-xs px-2 py-0.5 rounded font-medium ${reportFormat === 'CSV' ? 'bg-green-500/20 text-green-400' : 'bg-blue-500/20 text-blue-400'}`}>
                      {reportFormat}
                    </span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-muted-foreground w-20">Schedule:</span> 
                    <span className="capitalize">{reportSchedule}</span>
                  </li>
                  <li className="flex gap-2 mt-4 pt-4 border-t border-border">
                    <span className="text-muted-foreground w-20">Est. rows:</span> 
                    <span className="font-mono">{estRows.toLocaleString()}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'preview' && (
          <div className="animate-in fade-in">
            <div className="flex justify-between items-center mb-4">
              <div>
                <h2 className="text-lg font-semibold">{reportName || SAVED_REPORTS[0].name}</h2>
                <p className="text-sm text-muted-foreground">Last generated Feb 1, 2024</p>
              </div>
              <button className="flex items-center gap-2 px-3 py-1.5 bg-secondary border border-border rounded-md text-sm font-medium hover:bg-secondary/80">
                <Download className="w-4 h-4" /> Export CSV
              </button>
            </div>

            <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-muted/10 border-b border-border text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-4 py-3 font-medium">Date</th>
                      <th className="px-4 py-3 font-medium">Sessions</th>
                      <th className="px-4 py-3 font-medium">Human</th>
                      <th className="px-4 py-3 font-medium">Bot</th>
                      <th className="px-4 py-3 font-medium">Human Rate %</th>
                      <th className="px-4 py-3 font-medium">Avg Score</th>
                      <th className="px-4 py-3 font-medium">Bots Blocked</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {PREVIEW_DATA.map((row, i) => (
                      <tr key={i} className="hover:bg-secondary/20">
                        <td className="px-4 py-3">{row.date}</td>
                        <td className="px-4 py-3">{row.sessions}</td>
                        <td className="px-4 py-3">{row.human}</td>
                        <td className="px-4 py-3">{row.bot}</td>
                        <td className="px-4 py-3 text-green-400 font-medium">{row.humanRate}</td>
                        <td className="px-4 py-3 text-cyan-400 font-medium">{row.avgScore}</td>
                        <td className="px-4 py-3">{row.blocked}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="p-4 border-t border-border bg-muted/5 text-sm text-muted-foreground text-center">
                Showing 10 of 31 rows — Export to see full dataset
              </div>
            </div>
          </div>
        )}

      </div>
    </AppLayout>
  );
}