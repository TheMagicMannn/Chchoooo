import { useState, useEffect } from "react";
import { Layout } from "@/components/layout";
import { Copy, Check, ChevronRight, CheckCircle, Wifi } from "lucide-react";
import { Link } from "wouter";
import { CodeBlock } from "@/components/code-block";

export default function Onboarding() {
  const [step, setStep] = useState(1);
  const [domain, setDomain] = useState("");
  const [token] = useState(() => crypto.randomUUID());
  const [copied, setCopied] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<"gtm" | "wordpress" | null>(null);
  const [verifying, setVerifying] = useState(true);

  const handleCopy = () => {
    navigator.clipboard.writeText(token);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    if (step === 4) {
      setVerifying(true);
      const timer = setTimeout(() => {
        setVerifying(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [step]);

  const gtmLines = [
    "<!-- Proof of Human · GTM Custom HTML · Trigger: All Pages -->",
    "<script>",
    "(function() {",
    "  window.PoH = {",
    '    token: "' + token + '",',
    "    sessionId: crypto.randomUUID()",
    "  };",
    '  var s = document.createElement("script");',
    '  s.src = "https://cdn.proofofhuman.io/sdk/v2.min.js";',
    "  s.async = true;",
    "  document.head.appendChild(s);",
    "})();",
    "</script>"
  ];
  const gtmCode = gtmLines.join("\n");

  return (
    <Layout>
      <div className="w-full max-w-3xl mx-auto px-4 py-12">
        {/* STEP INDICATOR */}
        <div className="flex items-center justify-between mb-12 relative">
          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-0.5 bg-border -z-10"></div>
          {[1, 2, 3, 4].map((i) => {
            const isCompleted = step > i;
            const isCurrent = step === i;
            return (
              <div key={i} className="flex flex-col items-center bg-background px-2">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm border-2 ${
                  isCompleted ? "bg-primary border-primary text-primary-foreground" :
                  isCurrent ? "border-primary text-primary bg-background" :
                  "border-border text-muted-foreground bg-background"
                }`}>
                  {isCompleted ? <Check className="w-4 h-4" /> : i}
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-card border border-border rounded-xl p-8 shadow-sm">
          {step === 1 && (
            <div className="animate-in fade-in slide-in-from-bottom-4">
              <h2 className="text-2xl font-bold mb-6">Generate Your API Token</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Website Domain</label>
                  <input
                    type="text"
                    value={domain}
                    onChange={(e) => setDomain(e.target.value)}
                    placeholder="yourstore.com"
                    className="w-full bg-background border border-input rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Your API Token</label>
                  <div className="flex items-center gap-3">
                    <div className="flex-1 bg-[#0d1117] border border-primary/50 text-cyan-400 font-mono text-sm px-4 py-3 rounded-md overflow-hidden text-ellipsis">
                      {token}
                    </div>
                    <button
                      onClick={handleCopy}
                      className="px-4 py-3 bg-secondary hover:bg-secondary/80 border border-border rounded-md font-medium text-sm transition-colors flex items-center gap-2 shrink-0"
                    >
                      {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                      {copied ? "Copied!" : "Copy"}
                    </button>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    This token links your site to your Proof of Human account. Keep it private.
                  </p>
                </div>

                <div className="pt-4">
                  <button
                    onClick={() => setStep(2)}
                    className="w-full py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-md font-semibold transition-colors flex items-center justify-center gap-2"
                  >
                    Continue <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-in fade-in slide-in-from-bottom-4">
              <h2 className="text-2xl font-bold mb-6">Choose Install Method</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <button
                  onClick={() => setSelectedMethod("gtm")}
                  className={`text-left p-6 rounded-lg border-2 transition-all ${
                    selectedMethod === "gtm" 
                      ? "border-primary bg-primary/5" 
                      : "border-border hover:border-primary/50 bg-background"
                  }`}
                >
                  <h3 className="font-bold text-lg mb-2">Google Tag Manager</h3>
                  <p className="text-sm text-muted-foreground">Recommended. Paste one tag, no code changes.</p>
                </button>
                
                <button
                  onClick={() => setSelectedMethod("wordpress")}
                  className={`text-left p-6 rounded-lg border-2 transition-all ${
                    selectedMethod === "wordpress" 
                      ? "border-primary bg-primary/5" 
                      : "border-border hover:border-primary/50 bg-background"
                  }`}
                >
                  <h3 className="font-bold text-lg mb-2">WordPress Plugin</h3>
                  <p className="text-sm text-muted-foreground">Install from wp-admin, activate, paste your token.</p>
                </button>
              </div>

              <details className="mb-8 group">
                <summary className="text-sm font-medium text-muted-foreground cursor-pointer hover:text-foreground">
                  Other methods
                </summary>
                <div className="pt-3 text-sm text-muted-foreground">
                  Direct script tag · Shopify ScriptTag API · Squarespace Code Injection
                </div>
              </details>

              <button
                onClick={() => setStep(3)}
                disabled={!selectedMethod}
                className="w-full py-3 bg-primary hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed text-primary-foreground rounded-md font-semibold transition-colors flex items-center justify-center gap-2"
              >
                Continue <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {step === 3 && selectedMethod === "gtm" && (
            <div className="animate-in fade-in slide-in-from-bottom-4">
              <h2 className="text-2xl font-bold mb-6">Add this tag to Google Tag Manager</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex gap-3 text-sm"><span className="font-bold text-primary">1.</span> Open Google Tag Manager, go to Tags, click New</div>
                <div className="flex gap-3 text-sm"><span className="font-bold text-primary">2.</span> Choose tag type: Custom HTML</div>
                <div className="flex gap-3 text-sm"><span className="font-bold text-primary">3.</span> Paste the code below into the HTML field</div>
                <div className="flex gap-3 text-sm"><span className="font-bold text-primary">4.</span> Set trigger to: All Pages</div>
                <div className="flex gap-3 text-sm"><span className="font-bold text-primary">5.</span> Click Submit to publish your container</div>
              </div>

              <CodeBlock code={gtmCode} language="html" />

              <div className="pt-6 border-t border-border mt-8">
                <button
                  onClick={() => setStep(4)}
                  className="w-full py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-md font-semibold transition-colors"
                >
                  My tag is live — Verify
                </button>
              </div>
            </div>
          )}

          {step === 3 && selectedMethod === "wordpress" && (
            <div className="animate-in fade-in slide-in-from-bottom-4">
              <h2 className="text-2xl font-bold mb-6">Install via WordPress Admin</h2>
              
              <div className="space-y-4 mb-8">
                <div className="flex gap-3 items-center text-sm">
                  <span className="font-bold text-primary shrink-0">1.</span> Go to wp-admin → Plugins → Add New → Upload Plugin
                </div>
                <div className="flex gap-3 items-center text-sm">
                  <span className="font-bold text-primary shrink-0">2.</span> 
                  Upload the file: proof-of-human.zip
                  <button className="ml-2 px-3 py-1 bg-secondary text-secondary-foreground text-xs rounded border border-border hover:bg-secondary/80">Download Plugin</button>
                </div>
                <div className="flex gap-3 items-center text-sm"><span className="font-bold text-primary shrink-0">3.</span> Click Activate Plugin</div>
                <div className="flex gap-3 items-center text-sm"><span className="font-bold text-primary shrink-0">4.</span> Go to Settings → Proof of Human</div>
                <div className="flex gap-3 items-center text-sm"><span className="font-bold text-primary shrink-0">5.</span> Paste your token in the API Token field and click Save Changes</div>
              </div>

              <div className="bg-[#1e1e1e] border border-border rounded-md overflow-hidden mb-8 max-w-md mx-auto">
                <div className="bg-[#2d2d2d] px-4 py-2 border-b border-border/50 font-medium text-sm flex items-center text-white/90">
                  Settings <ChevronRight className="w-3 h-3 mx-1 opacity-50" /> Proof of Human
                </div>
                <div className="p-5 space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-white/70 mb-1">API Token</label>
                    <input type="text" readOnly value={token} className="w-full bg-[#1e1e1e] border border-[#555] rounded px-3 py-1.5 text-sm text-cyan-400 font-mono outline-none" />
                  </div>
                  <button className="bg-[#2271b1] hover:bg-[#135e96] text-white text-sm font-medium px-4 py-1.5 rounded transition-colors">
                    Save Changes
                  </button>
                </div>
              </div>

              <div className="pt-6 border-t border-border mt-8">
                <button
                  onClick={() => setStep(4)}
                  className="w-full py-3 bg-primary hover:bg-primary/90 text-primary-foreground rounded-md font-semibold transition-colors"
                >
                  My tag is live — Verify
                </button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="animate-in fade-in slide-in-from-bottom-4 text-center py-8">
              {verifying ? (
                <div className="flex flex-col items-center">
                  <div className="relative mb-6">
                    <div className="absolute inset-0 bg-primary/20 rounded-full animate-ping"></div>
                    <Wifi className="w-16 h-16 text-primary relative z-10 animate-pulse" />
                  </div>
                  <h2 className="text-xl font-bold mb-2">Checking for signal from {domain || "your site"}...</h2>
                  <p className="text-muted-foreground">This usually takes a few seconds.</p>
                </div>
              ) : (
                <div className="flex flex-col items-center animate-in zoom-in-95 duration-300">
                  <CheckCircle className="w-20 h-20 text-green-500 mb-6" />
                  <h2 className="text-2xl font-bold mb-2">Connected! We received your first events.</h2>
                  <p className="text-muted-foreground mb-8">Proof of Human is now actively scoring traffic on your site.</p>
                  
                  <div className="w-full border border-border rounded-lg overflow-hidden mb-8 text-left">
                    <table className="w-full text-sm">
                      <thead className="bg-secondary/50 border-b border-border">
                        <tr>
                          <th className="px-4 py-2 font-medium text-muted-foreground">Session ID</th>
                          <th className="px-4 py-2 font-medium text-muted-foreground">Score</th>
                          <th className="px-4 py-2 font-medium text-muted-foreground">Verdict</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border font-mono">
                        <tr>
                          <td className="px-4 py-3">sess_a8f2...</td>
                          <td className="px-4 py-3">0.91</td>
                          <td className="px-4 py-3"><span className="bg-green-500/20 text-green-500 px-2 py-0.5 rounded text-xs">HUMAN</span></td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3">sess_c34b...</td>
                          <td className="px-4 py-3">0.87</td>
                          <td className="px-4 py-3"><span className="bg-green-500/20 text-green-500 px-2 py-0.5 rounded text-xs">HUMAN</span></td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3">sess_x99z...</td>
                          <td className="px-4 py-3">0.03</td>
                          <td className="px-4 py-3"><span className="bg-red-500/20 text-red-500 px-2 py-0.5 rounded text-xs">BOT</span></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  <div className="flex gap-4 w-full justify-center">
                    <Link href="/connect" className="px-6 py-2 bg-primary text-primary-foreground rounded-md font-medium hover:bg-primary/90 transition-colors">
                      Open Dashboard
                    </Link>
                    <Link href="/docs" className="px-6 py-2 bg-secondary text-secondary-foreground rounded-md font-medium border border-border hover:bg-secondary/80 transition-colors">
                      Read Integration Docs
                    </Link>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>
      </div>
    </Layout>
  );
}
