import { useState } from 'react';
import { useLocation } from 'wouter';
import { ShieldCheck, Eye, EyeOff, ArrowRight } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [, navigate] = useLocation();

  const handleSignIn = () => {
    if (!email.trim()) { setError('Email is required'); return; }
    setIsLoading(true); setError('');
    setTimeout(() => {
      const namePart = email.split('@')[0];
      const name = namePart.charAt(0).toUpperCase() + namePart.slice(1);
      localStorage.setItem('poh_user', JSON.stringify({ email, name, plan: 'Growth', signedInAt: new Date().toISOString() }));
      navigate('/connect');
    }, 800);
  };

  const handleDemo = () => {
    setIsLoading(true);
    setTimeout(() => {
      localStorage.setItem('poh_user', JSON.stringify({ email: 'demo@proofofhuman.io', name: 'Demo User', plan: 'Growth', signedInAt: new Date().toISOString() }));
      navigate('/connect');
    }, 400);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        <div className="text-center mb-8">
          <div className="inline-flex w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 items-center justify-center mb-4">
            <ShieldCheck className="w-7 h-7 text-primary" />
          </div>
          <h1 className="text-2xl font-bold">Proof of Human</h1>
          <p className="text-muted-foreground mt-2">Sign in to your account</p>
        </div>

        <div className="bg-card border border-border rounded-2xl p-8 shadow-xl">
          {error && (
            <div className="bg-red-500/10 border border-red-500/20 text-red-400 text-sm px-4 py-3 rounded-lg mb-4">
              {error}
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Email address</label>
              <input 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-secondary border border-border rounded-lg px-3 py-2 text-sm outline-none focus:border-primary transition-colors"
                placeholder="you@example.com"
              />
            </div>

            <div className="relative">
              <label className="block text-sm font-medium text-foreground mb-1.5">Password</label>
              <input 
                type={showPassword ? "text" : "password"} 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-secondary border border-border rounded-lg pl-3 pr-10 py-2 text-sm outline-none focus:border-primary transition-colors"
                placeholder="••••••••"
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-[30px] text-muted-foreground hover:text-foreground transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>

            <button 
              onClick={handleSignIn}
              disabled={isLoading}
              className="w-full bg-primary text-primary-foreground py-2.5 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors flex justify-center items-center gap-2 mt-2 disabled:opacity-70"
            >
              {isLoading ? 'Signing in...' : 'Sign In'}
              {!isLoading && <ArrowRight className="w-4 h-4" />}
            </button>
          </div>

          <div className="my-6 relative border-t border-border">
            <div className="absolute left-1/2 -translate-x-1/2 -top-2.5 bg-card px-2 text-xs text-muted-foreground uppercase">or</div>
          </div>

          <button 
            onClick={handleDemo}
            disabled={isLoading}
            className="w-full border border-border bg-transparent hover:bg-secondary py-2.5 rounded-lg text-sm font-medium transition-colors disabled:opacity-70"
          >
            {isLoading ? 'Loading...' : 'Continue as Demo'}
          </button>
        </div>

        <div className="text-center mt-6 space-y-2">
          <p className="text-sm text-muted-foreground">
            No account? <a href="/onboarding" className="text-primary hover:underline">Get started free</a>
          </p>
          <p>
            <a href="#" className="text-xs text-muted-foreground/60 hover:text-muted-foreground transition-colors">Enterprise SSO</a>
          </p>
        </div>

      </div>
    </div>
  );
}