import { useState } from "react";
import { AppLayout } from "@/components/app-layout";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceArea } from "recharts";
import { Play, Activity } from "lucide-react";

export default function Risk() {
  const [activeTab, setActiveTab] = useState("Scoring");

  const tabs = ["Scoring", "Fingerprints", "Anomaly", "Session Replay"];

  const MVPBadge = () => <span className="text-xs font-mono bg-primary/20 text-primary px-1.5 py-0.5 rounded ml-2">MVP</span>;
  const EnterpriseBadge = () => <span className="text-xs font-mono bg-purple-500/20 text-purple-400 px-1.5 py-0.5 rounded ml-2">ENTERPRISE</span>;

  const anomalyData = Array.from({ length: 30 }).map((_, i) => {
    let val = Math.random() * 5 + 5;
    if (i === 12) val = 35; // spike
    if (i === 13) val = 28;
    if (i === 28) val = 38; // recent spike
    return { day: i + 1, botRate: val };
  });

  return (
    <AppLayout>
      <div className="p-6 md:p-10 max-w-6xl mx-auto w-full">
        <h1 className="text-3xl font-bold mb-6">Risk & Detection</h1>
        
        <div className="flex overflow-x-auto space-x-2 border-b border-border/40 mb-6 pb-px hide-scrollbar">
          {tabs.map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === t
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {activeTab === "Scoring" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center">Adaptive Risk Scoring <MVPBadge /></h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Each session receives a composite risk score from 0.0 to 1.0. Scores below 0.5 trigger escalation. The model weighs mouse trajectory entropy, keystroke cadence, scroll velocity, and network fingerprint.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <h3 className="font-medium mb-6">Score Distribution Thresholds</h3>
              <div className="relative h-6 w-full rounded overflow-hidden flex bg-gradient-to-r from-red-500 via-yellow-500 to-green-500">
              </div>
              <div className="relative w-full h-12 mt-2">
                <div className="absolute left-[30%] -translate-x-1/2 flex flex-col items-center">
                  <div className="w-0.5 h-4 bg-red-500 mb-1"></div>
                  <span className="text-xs text-red-500 font-medium whitespace-nowrap">Block (&lt; 0.3)</span>
                </div>
                <div className="absolute left-[50%] -translate-x-1/2 flex flex-col items-center">
                  <div className="w-0.5 h-4 bg-yellow-500 mb-1"></div>
                  <span className="text-xs text-yellow-500 font-medium whitespace-nowrap">CAPTCHA (0.3–0.5)</span>
                </div>
                <div className="absolute left-[70%] -translate-x-1/2 flex flex-col items-center">
                  <div className="w-0.5 h-4 bg-green-500 mb-1"></div>
                  <span className="text-xs text-green-500 font-medium whitespace-nowrap">Trusted (&gt; 0.7)</span>
                </div>
                
                {/* Ticks */}
                {[0.0, 0.2, 0.4, 0.6, 0.8, 1.0].map((tick, i) => (
                  <div key={i} className="absolute top-0 text-[10px] text-muted-foreground" style={{ left: (tick * 100) + "%", transform: 'translateX(-50%)' }}>
                    {tick.toFixed(1)}
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-border bg-muted/20">
                <h3 className="font-medium">Risk Factor Breakdown</h3>
              </div>
              <table className="w-full text-sm">
                <thead className="bg-muted/10 text-muted-foreground">
                  <tr>
                    <th className="px-6 py-3 text-left font-medium">Signal</th>
                    <th className="px-6 py-3 text-left font-medium">Weight</th>
                    <th className="px-6 py-3 text-left font-medium">Avg Score</th>
                    <th className="px-6 py-3 text-left font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3">Mouse Trajectory Entropy</td>
                    <td className="px-6 py-3">28%</td>
                    <td className="px-6 py-3 font-mono">0.84</td>
                    <td className="px-6 py-3"><span className="bg-green-500/20 text-green-500 px-2 py-0.5 rounded text-xs">Good</span></td>
                  </tr>
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3">Keystroke Cadence</td>
                    <td className="px-6 py-3">22%</td>
                    <td className="px-6 py-3 font-mono">0.71</td>
                    <td className="px-6 py-3"><span className="bg-green-500/20 text-green-500 px-2 py-0.5 rounded text-xs">Good</span></td>
                  </tr>
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3">Scroll Velocity Pattern</td>
                    <td className="px-6 py-3">18%</td>
                    <td className="px-6 py-3 font-mono">0.69</td>
                    <td className="px-6 py-3"><span className="bg-yellow-500/20 text-yellow-500 px-2 py-0.5 rounded text-xs">Watch</span></td>
                  </tr>
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3">Network Fingerprint</td>
                    <td className="px-6 py-3">17%</td>
                    <td className="px-6 py-3 font-mono">0.91</td>
                    <td className="px-6 py-3"><span className="bg-green-500/20 text-green-500 px-2 py-0.5 rounded text-xs">Good</span></td>
                  </tr>
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3">Session Timing</td>
                    <td className="px-6 py-3">15%</td>
                    <td className="px-6 py-3 font-mono">0.58</td>
                    <td className="px-6 py-3"><span className="bg-yellow-500/20 text-yellow-500 px-2 py-0.5 rounded text-xs">Watch</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === "Fingerprints" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center">Bot Fingerprint Clustering <EnterpriseBadge /></h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Detected bot clusters are automatically grouped by behavioral signature. Each cluster shares common fingerprint attributes.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-semibold text-lg">Cluster A</h3>
                  <span className="bg-red-500/20 text-red-500 px-2 py-1 rounded text-xs font-semibold">Blocked</span>
                </div>
                <p className="text-sm text-muted-foreground mb-4">"Headless Browser Farm"</p>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Sessions</span>
                    <span className="font-mono">234</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Confidence</span>
                    <span className="font-mono text-green-400">98%</span>
                  </div>
                  <div className="pt-2">
                    <span className="text-xs text-muted-foreground uppercase tracking-wider">Signals</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">No mouse movement</span>
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">Perfect timing</span>
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">Missing UA plugins</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-semibold text-lg">Cluster B</h3>
                  <span className="bg-yellow-500/20 text-yellow-500 px-2 py-1 rounded text-xs font-semibold">Monitoring</span>
                </div>
                <p className="text-sm text-muted-foreground mb-4">"Click Farm (Mobile)"</p>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Sessions</span>
                    <span className="font-mono">89</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Confidence</span>
                    <span className="font-mono text-green-400">87%</span>
                  </div>
                  <div className="pt-2">
                    <span className="text-xs text-muted-foreground uppercase tracking-wider">Signals</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">Repetitive scroll</span>
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">High touch freq</span>
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">Low entropy</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-semibold text-lg">Cluster C</h3>
                  <span className="bg-orange-500/20 text-orange-500 px-2 py-1 rounded text-xs font-semibold">Flagged</span>
                </div>
                <p className="text-sm text-muted-foreground mb-4">"Residential Proxy Network"</p>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Sessions</span>
                    <span className="font-mono">412</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Confidence</span>
                    <span className="font-mono text-yellow-400">76%</span>
                  </div>
                  <div className="pt-2">
                    <span className="text-xs text-muted-foreground uppercase tracking-wider">Signals</span>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">IP rotation</span>
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">Human-like movement</span>
                      <span className="bg-secondary text-xs px-2 py-1 rounded-md border border-border">VPN fingerprint</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "Anomaly" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center">Anomaly Detection Timeline <EnterpriseBadge /></h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Automated anomaly detection surfaces unusual traffic spikes and behavioral pattern shifts.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <h3 className="font-medium mb-6">Bot Rate Anomalies (Last 30 Days)</h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={anomalyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                    <XAxis dataKey="day" stroke="#666" tick={{fontSize: 12}} />
                    <YAxis stroke="#666" tick={{fontSize: 12}} tickFormatter={(val) => val + "%"} />
                    <Tooltip contentStyle={{ backgroundColor: '#111827', border: '1px solid #333' }} />
                    <ReferenceArea x1={12} x2={14} fill="rgba(239, 68, 68, 0.2)" />
                    <ReferenceArea x1={27} x2={29} fill="rgba(239, 68, 68, 0.2)" />
                    <Line type="monotone" dataKey="botRate" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-medium text-lg">Recent Anomalies</h3>
              <div className="border-l-2 border-border pl-6 space-y-6 relative ml-2">
                <div className="relative">
                  <div className="absolute w-3 h-3 bg-red-500 rounded-full -left-[1.95rem] top-1.5 ring-4 ring-background"></div>
                  <div className="bg-card border border-border p-4 rounded-lg shadow-sm">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs text-muted-foreground font-mono">[2 days ago]</span>
                      <span className="bg-red-500/20 text-red-500 text-xs px-2 py-0.5 rounded font-medium">Severity: High</span>
                    </div>
                    <p className="text-sm font-medium mb-1">Traffic spike: 340% increase in sessions from AS16509 (Amazon)</p>
                    <p className="text-sm text-muted-foreground">Action: <span className="text-foreground">Auto-blocked</span></p>
                  </div>
                </div>

                <div className="relative">
                  <div className="absolute w-3 h-3 bg-yellow-500 rounded-full -left-[1.95rem] top-1.5 ring-4 ring-background"></div>
                  <div className="bg-card border border-border p-4 rounded-lg shadow-sm">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs text-muted-foreground font-mono">[5 days ago]</span>
                      <span className="bg-yellow-500/20 text-yellow-500 text-xs px-2 py-0.5 rounded font-medium">Severity: Medium</span>
                    </div>
                    <p className="text-sm font-medium mb-1">Pattern shift: Keystroke entropy dropped 42% across all sessions</p>
                    <p className="text-sm text-muted-foreground">Action: <span className="text-foreground">CAPTCHA escalation triggered</span></p>
                  </div>
                </div>

                <div className="relative">
                  <div className="absolute w-3 h-3 bg-red-500 rounded-full -left-[1.95rem] top-1.5 ring-4 ring-background"></div>
                  <div className="bg-card border border-border p-4 rounded-lg shadow-sm">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs text-muted-foreground font-mono">[11 days ago]</span>
                      <span className="bg-red-500/20 text-red-500 text-xs px-2 py-0.5 rounded font-medium">Severity: High</span>
                    </div>
                    <p className="text-sm font-medium mb-1">Cluster detected: 234 sessions sharing identical canvas fingerprint</p>
                    <p className="text-sm text-muted-foreground">Action: <span className="text-foreground">Cluster blocked</span></p>
                  </div>
                </div>

                <div className="relative">
                  <div className="absolute w-3 h-3 bg-red-600 rounded-full -left-[1.95rem] top-1.5 ring-4 ring-background shadow-[0_0_8px_rgba(220,38,38,0.8)]"></div>
                  <div className="bg-card border border-red-500/30 p-4 rounded-lg shadow-sm">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs text-muted-foreground font-mono">[18 days ago]</span>
                      <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded font-medium">Severity: Critical</span>
                    </div>
                    <p className="text-sm font-medium mb-1">Velocity anomaly: 8,200 sessions in 4 minutes from single /contact page</p>
                    <p className="text-sm text-muted-foreground">Action: <span className="text-foreground">Rate limit applied + alert sent</span></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "Session Replay" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center">Session Replay Preview <EnterpriseBadge /></h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Visual session replay helps review flagged sessions for false positives. Bot sessions show obvious patterns — perfect timing, no cursor variation, instant scrolls.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden max-w-3xl">
              <div className="px-4 py-3 bg-secondary/50 border-b border-border flex items-center justify-between text-sm">
                <div className="flex items-center gap-4">
                  <span className="font-mono text-muted-foreground">Session 8f3a2c</span>
                  <span className="bg-red-500/20 text-red-500 px-2 py-0.5 rounded text-xs font-semibold">BOT</span>
                  <span className="text-muted-foreground">Score: <span className="text-foreground font-mono">0.08</span></span>
                </div>
                <div className="text-xs text-muted-foreground truncate max-w-[200px]" title="HeadlessChrome/110">
                  UA: HeadlessChrome/110
                </div>
              </div>
              
              <div className="relative aspect-video bg-[#0a0a0a] flex items-center justify-center overflow-hidden">
                <div className="absolute top-4 right-4 flex items-center gap-2 bg-black/50 px-2 py-1 rounded text-xs border border-white/10">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                  Recording
                </div>
                <div className="text-muted-foreground/30 font-mono text-4xl select-none">REPLAY</div>
                
                {/* Fake cursor */}
                <div className="absolute top-[40%] left-[30%] w-4 h-4 text-white drop-shadow-md">
                  <svg viewBox="0 0 24 24" fill="currentColor" stroke="black" strokeWidth="1.5">
                    <path d="M5.5 3.21V20.8c0 .45.54.67.85.35l4.86-4.86a.5.5 0 01.35-.15h6.87c.45 0 .67-.54.35-.85L6.35 2.86a.5.5 0 00-.85.35z"></path>
                  </svg>
                </div>
              </div>

              <div className="px-4 py-3 bg-secondary/30 border-t border-border flex items-center gap-4">
                <button className="text-foreground hover:text-primary transition-colors">
                  <Play className="h-5 w-5" fill="currentColor" />
                </button>
                <div className="flex-1 relative h-2 bg-muted rounded-full overflow-hidden">
                  <div className="absolute top-0 left-0 h-full w-[33%] bg-primary"></div>
                  <div className="absolute top-0 left-[10%] w-1.5 h-full bg-yellow-500 z-10" title="Event marker"></div>
                  <div className="absolute top-0 left-[25%] w-1.5 h-full bg-red-500 z-10" title="Event marker"></div>
                  <div className="absolute top-0 left-[30%] w-1.5 h-full bg-yellow-500 z-10" title="Event marker"></div>
                </div>
                <div className="font-mono text-xs text-muted-foreground">0:04 / 0:12</div>
              </div>
            </div>

            <div className="bg-secondary/30 border border-border p-4 rounded-lg max-w-3xl text-sm">
              <span className="font-medium">Events captured:</span> 847 mousemove, 0 keydown, 12 scroll <span className="text-muted-foreground">(all programmatic intervals detected)</span>
            </div>

            <div className="flex items-center gap-3 pt-4">
              <button className="px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-secondary transition-colors">
                Mark as False Positive
              </button>
              <button className="px-4 py-2 bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-500/20 rounded-md text-sm font-medium transition-colors">
                Confirm Bot — Add to Blocklist
              </button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
