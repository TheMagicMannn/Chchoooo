import { useState, useEffect } from "react";
import { Layout } from "@/components/layout";
import { Activity, ShieldAlert, Cpu, Users } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";

const generateLineData = () => Array.from({ length: 24 }).map((_, i) => ({
  time: `${i}:00`,
  events: Math.floor(Math.random() * 5000) + 8000
}));

const distData = [
  { bucket: "0.0-0.2", count: 120 },
  { bucket: "0.2-0.4", count: 340 },
  { bucket: "0.4-0.6", count: 890 },
  { bucket: "0.6-0.8", count: 2100 },
  { bucket: "0.8-1.0", count: 8500 },
];

const recentSessions = [
  { id: "sess_x8a9...", agent: "Mozilla/5.0 (Macintosh...", score: 0.98, time: "Just now", verdict: "HUMAN" },
  { id: "sess_y12b...", agent: "python-requests/2.26", score: 0.12, time: "2s ago", verdict: "BOT" },
  { id: "sess_z45c...", agent: "Mozilla/5.0 (Windows...", score: 0.88, time: "5s ago", verdict: "HUMAN" },
  { id: "sess_w99d...", agent: "HeadlessChrome/91.0", score: 0.05, time: "12s ago", verdict: "BOT" },
];

export default function Dashboard() {
  const [lineData, setLineData] = useState(generateLineData());
  const [eventsSec, setEventsSec] = useState(12847);

  // Fake live updates
  useEffect(() => {
    const interval = setInterval(() => {
      setEventsSec((prev) => prev + Math.floor(Math.random() * 200 - 100));
      setLineData((prev) => {
        const newData = [...prev.slice(1)];
        newData.push({
          time: "Now",
          events: Math.floor(Math.random() * 5000) + 8000
        });
        return newData;
      });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Layout>
      <div className="w-full max-w-7xl mx-auto px-4 py-8 space-y-6">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <div className="flex items-center gap-2 text-sm text-green-500 bg-green-500/10 px-3 py-1 rounded-full border border-green-500/20">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            System Online
          </div>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-6 rounded-xl border border-border bg-card shadow-sm">
            <div className="flex items-center justify-between text-muted-foreground mb-4">
              <span className="text-sm font-medium">Events / Sec</span>
              <Activity className="h-4 w-4" />
            </div>
            <div className="text-3xl font-bold font-mono text-foreground">{eventsSec.toLocaleString()}</div>
          </div>
          <div className="p-6 rounded-xl border border-border bg-card shadow-sm">
            <div className="flex items-center justify-between text-muted-foreground mb-4">
              <span className="text-sm font-medium">Avg Inference</span>
              <Cpu className="h-4 w-4" />
            </div>
            <div className="text-3xl font-bold font-mono text-cyan-400">4.2ms</div>
          </div>
          <div className="p-6 rounded-xl border border-border bg-card shadow-sm">
            <div className="flex items-center justify-between text-muted-foreground mb-4">
              <span className="text-sm font-medium">Human Score P90</span>
              <ShieldAlert className="h-4 w-4" />
            </div>
            <div className="text-3xl font-bold font-mono text-primary">0.94</div>
          </div>
          <div className="p-6 rounded-xl border border-border bg-card shadow-sm">
            <div className="flex items-center justify-between text-muted-foreground mb-4">
              <span className="text-sm font-medium">Sessions Today</span>
              <Users className="h-4 w-4" />
            </div>
            <div className="text-3xl font-bold font-mono text-foreground">89,234</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Chart */}
          <div className="lg:col-span-2 p-6 rounded-xl border border-border bg-card shadow-sm">
            <h3 className="font-semibold mb-6">Event Throughput (24h)</h3>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={lineData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="time" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#111827', border: '1px solid #333' }}
                    itemStyle={{ color: '#00f0ff' }}
                  />
                  <Line type="monotone" dataKey="events" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Bar Chart */}
          <div className="p-6 rounded-xl border border-border bg-card shadow-sm">
            <h3 className="font-semibold mb-6">Score Distribution</h3>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={distData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="bucket" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip 
                    cursor={{fill: '#222'}} 
                    contentStyle={{ backgroundColor: '#111827', border: '1px solid #333' }}
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="p-6 rounded-xl border border-border bg-card shadow-sm overflow-hidden">
          <h3 className="font-semibold mb-6">Recent Inferences</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs uppercase text-muted-foreground border-b border-border/50">
                <tr>
                  <th className="px-4 py-3">Session ID</th>
                  <th className="px-4 py-3">User Agent</th>
                  <th className="px-4 py-3">Score</th>
                  <th className="px-4 py-3">Timestamp</th>
                  <th className="px-4 py-3">Verdict</th>
                </tr>
              </thead>
              <tbody>
                {recentSessions.map((row, i) => (
                  <tr key={i} className="border-b border-border/20 hover:bg-secondary/50 transition-colors">
                    <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{row.id}</td>
                    <td className="px-4 py-3 truncate max-w-[200px]" title={row.agent}>{row.agent}</td>
                    <td className="px-4 py-3 font-mono">{row.score.toFixed(2)}</td>
                    <td className="px-4 py-3 text-muted-foreground">{row.time}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-md text-xs font-semibold ${row.verdict === 'HUMAN' ? 'bg-primary/20 text-primary' : 'bg-destructive/20 text-destructive'}`}>
                        {row.verdict}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </Layout>
  );
}
