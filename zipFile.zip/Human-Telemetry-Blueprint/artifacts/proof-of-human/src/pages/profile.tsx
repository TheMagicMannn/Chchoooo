import { useState, useEffect } from 'react';
import { AppLayout } from '@/components/app-layout';
import { useLocation } from 'wouter';
import { User, Bell, Shield, LogOut, Check } from 'lucide-react';

export default function Profile() {
  const [, navigate] = useLocation();
  const [user, setUser] = useState<{ email: string; name: string; plan: string; signedInAt: string } | null>(null);
  const [notifSettings, setNotifSettings] = useState({ critical: true, digest: true, captcha: true, cluster: false, api: false });
  const [saved, setSaved] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    try {
      const u = JSON.parse(localStorage.getItem('poh_user') || 'null');
      if (u) setUser(u);
      else setUser({ email: 'demo@proofofhuman.io', name: 'Demo User', plan: 'Growth', signedInAt: new Date().toISOString() });
    } catch (e) {
      setUser({ email: 'demo@proofofhuman.io', name: 'Demo User', plan: 'Growth', signedInAt: new Date().toISOString() });
    }
  }, []);

  const handleSignOut = () => { 
    localStorage.removeItem('poh_user'); 
    navigate('/login'); 
  };

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => { 
      setIsSaving(false); 
      setSaved(true); 
      setTimeout(() => setSaved(false), 2000); 
    }, 600);
  };

  const toggleNotif = (key: keyof typeof notifSettings) => setNotifSettings(prev => ({ ...prev, [key]: !prev[key] }));

  return (
    <AppLayout>
      <div className="p-6 max-w-3xl mx-auto space-y-6 relative pb-24">
        
        <div>
          <h1 className="text-2xl font-bold">Account & Profile</h1>
          <p className="text-muted-foreground text-sm">{user?.email}</p>
        </div>

        {/* SECTION 1 */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 border-2 border-primary/30 flex items-center justify-center text-2xl font-bold text-primary shrink-0">
              {user?.name?.charAt(0) || 'D'}
            </div>
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-xl font-semibold">{user?.name}</h2>
                  <p className="text-muted-foreground text-sm">{user?.email}</p>
                  <div className="inline-block bg-primary/20 text-primary text-xs px-2 py-0.5 rounded font-medium mt-2">
                    {user?.plan} Plan
                  </div>
                  <div className="flex gap-4 mt-3 text-xs text-muted-foreground">
                    <span>Member since: January 2024</span>
                    <span>Last sign in: {user?.signedInAt?.slice(0,10) || 'Today'}</span>
                  </div>
                </div>
                <button className="px-3 py-1.5 border border-border rounded-md text-sm font-medium hover:bg-secondary transition-colors">
                  Edit Profile
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 2 */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <div className="flex items-center gap-2 mb-6">
            <Bell className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">Notifications</h3>
          </div>
          <div className="space-y-4">
            {[
              { key: 'critical', label: 'Critical alerts', desc: 'Immediate email when bot cluster detected' },
              { key: 'digest', label: 'Weekly digest', desc: 'Traffic quality summary every Monday' },
              { key: 'captcha', label: 'CAPTCHA spike alerts', desc: 'When trigger rate exceeds 20%' },
              { key: 'cluster', label: 'New bot clusters', desc: 'When new fingerprint cluster is identified' },
              { key: 'api', label: 'API usage warnings', desc: 'When API quota reaches 80%' }
            ].map(item => (
              <div key={item.key} className="flex justify-between items-center">
                <div>
                  <div className="font-medium text-sm">{item.label}</div>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
                <button 
                  onClick={() => toggleNotif(item.key as keyof typeof notifSettings)}
                  className={`w-10 h-6 rounded-full flex items-center px-1 transition-colors ${
                    notifSettings[item.key as keyof typeof notifSettings] ? 'bg-primary justify-end' : 'bg-secondary/80 justify-start'
                  }`}
                >
                  <div className="w-4 h-4 rounded-full bg-white shadow-sm"></div>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* SECTION 3 */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold mb-6">API Usage — Current Period</h3>
          <div className="space-y-5">
            <div>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="font-medium">Sessions this month</span>
                <span className="text-muted-foreground text-xs">287,432 / 500,000 (57%)</span>
              </div>
              <div className="bg-secondary rounded-full h-2 w-full overflow-hidden">
                <div className="bg-primary rounded-full h-2 transition-all" style={{ width: '57%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="font-medium">API calls</span>
                <span className="text-muted-foreground text-xs">48,291 / 100,000 (48%)</span>
              </div>
              <div className="bg-secondary rounded-full h-2 w-full overflow-hidden">
                <div className="bg-primary rounded-full h-2 transition-all" style={{ width: '48%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-sm mb-1.5">
                <span className="font-medium">Webhooks fired</span>
                <span className="text-muted-foreground text-xs">1,243 / 10,000 (12%)</span>
              </div>
              <div className="bg-secondary rounded-full h-2 w-full overflow-hidden">
                <div className="bg-primary rounded-full h-2 transition-all" style={{ width: '12%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* SECTION 4 */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <div className="flex items-center gap-2 mb-6">
            <Shield className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold">Security</h3>
          </div>
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
              <span className="font-medium text-sm">Two-Factor Authentication</span>
              <span className="bg-red-500/20 text-red-400 text-xs px-2 py-0.5 rounded font-medium">Disabled</span>
            </div>
            <button className="px-3 py-1.5 border border-border rounded-md text-sm font-medium hover:bg-secondary transition-colors">
              Enable 2FA
            </button>
          </div>
          
          <div className="space-y-3">
            <h4 className="text-sm font-medium mb-2">Active Sessions</h4>
            <div className="flex justify-between items-center bg-secondary/30 p-3 rounded-lg border border-border/50">
              <div>
                <div className="text-sm font-medium flex items-center gap-2">
                  Chrome on macOS <span className="w-1 h-1 rounded-full bg-border"></span> San Francisco, CA
                  <span className="bg-green-500/20 text-green-500 text-[10px] px-1.5 py-0.5 rounded uppercase font-bold">Current</span>
                </div>
              </div>
              <button disabled className="px-2 py-1 text-xs border border-border rounded opacity-50 cursor-not-allowed">
                Revoke
              </button>
            </div>
            <div className="flex justify-between items-center bg-secondary/30 p-3 rounded-lg border border-border/50">
              <div>
                <div className="text-sm font-medium flex items-center gap-2">
                  Safari on iPhone <span className="w-1 h-1 rounded-full bg-border"></span> London, UK
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">2 days ago</div>
              </div>
              <button className="px-2 py-1 text-xs border border-border hover:bg-secondary rounded transition-colors">
                Revoke
              </button>
            </div>
          </div>
        </div>

        {/* SECTION 5 */}
        <div className="bg-card border border-red-900/30 rounded-xl p-6 shadow-sm">
          <h3 className="text-lg font-semibold text-red-400 mb-4">Danger Zone</h3>
          <div className="flex justify-between items-center">
            <div>
              <div className="font-medium text-sm">Delete Account</div>
              <p className="text-xs text-muted-foreground mt-0.5">Permanently deletes all data and configuration</p>
            </div>
            <button disabled title="Contact support" className="px-4 py-2 bg-red-600 text-white rounded-md text-sm font-medium opacity-50 cursor-not-allowed">
              Delete Account
            </button>
          </div>
          
          <div className="mt-6 border-t border-border pt-6">
            <button 
              onClick={handleSignOut}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 border border-border hover:bg-secondary rounded-md text-sm font-medium transition-colors"
            >
              <LogOut className="w-4 h-4 text-muted-foreground" /> Sign Out
            </button>
          </div>
        </div>

      </div>

      <div className="fixed bottom-0 left-0 md:left-56 right-0 bg-card border-t border-border p-4 flex justify-end items-center gap-4 z-10">
        {saved && (
          <span className="flex items-center gap-1.5 text-green-500 text-sm font-medium animate-in fade-in">
            <Check className="w-4 h-4" /> Preferences saved
          </span>
        )}
        <button 
          onClick={handleSave}
          disabled={isSaving}
          className="px-6 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-70"
        >
          {isSaving ? 'Saving...' : 'Save Preferences'}
        </button>
      </div>
    </AppLayout>
  );
}