import { useState } from "react";
import { AppLayout } from "@/components/app-layout";
import { Users, Shield, History, Search, CheckCircle2 } from "lucide-react";

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("Team & Access");
  const tabs = ["Team & Access", "Privacy & Consent", "Audit Log"];

  const MVPBadge = () => <span className="text-xs font-mono bg-primary/20 text-primary px-1.5 py-0.5 rounded ml-2">MVP</span>;
  const EnterpriseBadge = () => <span className="text-xs font-mono bg-purple-500/20 text-purple-400 px-1.5 py-0.5 rounded ml-2">ENTERPRISE</span>;

  return (
    <AppLayout>
      <div className="p-6 md:p-10 max-w-5xl mx-auto w-full">
        <h1 className="text-3xl font-bold mb-6">Settings & Governance</h1>
        
        <div className="flex overflow-x-auto space-x-2 border-b border-border/40 mb-8 pb-px hide-scrollbar">
          {tabs.map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === t
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t} {t === "Audit Log" ? <EnterpriseBadge /> : <MVPBadge />}
            </button>
          ))}
        </div>

        {activeTab === "Team & Access" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2"><Users className="w-5 h-5" /> Team Members</h2>
              <p className="text-muted-foreground mt-2">Manage who has access to your workspace and their permission levels.</p>
            </div>

            <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/20 text-muted-foreground border-b border-border/50">
                    <tr>
                      <th className="px-6 py-3 text-left font-medium">Name</th>
                      <th className="px-6 py-3 text-left font-medium">Email</th>
                      <th className="px-6 py-3 text-left font-medium">Role</th>
                      <th className="px-6 py-3 text-left font-medium">Last Active</th>
                      <th className="px-6 py-3 text-left font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    <tr className="hover:bg-muted/5">
                      <td className="px-6 py-4 font-medium">Alice Chen</td>
                      <td className="px-6 py-4 text-muted-foreground">alice@company.com</td>
                      <td className="px-6 py-4"><span className="bg-primary/20 text-primary px-2 py-0.5 rounded text-xs font-semibold">Admin</span></td>
                      <td className="px-6 py-4 text-muted-foreground">Just now</td>
                      <td className="px-6 py-4">
                        <div className="flex gap-3">
                          <button className="text-primary hover:underline text-xs font-medium">Edit</button>
                          <button className="text-red-500 hover:underline text-xs font-medium">Remove</button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-muted/5">
                      <td className="px-6 py-4 font-medium">Bob Kumar</td>
                      <td className="px-6 py-4 text-muted-foreground">bob@company.com</td>
                      <td className="px-6 py-4"><span className="bg-secondary px-2 py-0.5 rounded text-xs font-medium">Analyst</span></td>
                      <td className="px-6 py-4 text-muted-foreground">2 hr ago</td>
                      <td className="px-6 py-4">
                        <div className="flex gap-3">
                          <button className="text-primary hover:underline text-xs font-medium">Edit</button>
                          <button className="text-red-500 hover:underline text-xs font-medium">Remove</button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-muted/5">
                      <td className="px-6 py-4 font-medium">Carol Smith</td>
                      <td className="px-6 py-4 text-muted-foreground">carol@company.com</td>
                      <td className="px-6 py-4"><span className="bg-secondary px-2 py-0.5 rounded text-xs font-medium">Developer</span></td>
                      <td className="px-6 py-4 text-muted-foreground">Yesterday</td>
                      <td className="px-6 py-4">
                        <div className="flex gap-3">
                          <button className="text-primary hover:underline text-xs font-medium">Edit</button>
                          <button className="text-red-500 hover:underline text-xs font-medium">Remove</button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-muted/5">
                      <td className="px-6 py-4 font-medium">Dan Okafor</td>
                      <td className="px-6 py-4 text-muted-foreground">dan@company.com</td>
                      <td className="px-6 py-4"><span className="bg-secondary px-2 py-0.5 rounded text-xs font-medium text-muted-foreground">Viewer</span></td>
                      <td className="px-6 py-4 text-muted-foreground">3 days ago</td>
                      <td className="px-6 py-4">
                        <div className="flex gap-3">
                          <button className="text-primary hover:underline text-xs font-medium">Edit</button>
                          <button className="text-red-500 hover:underline text-xs font-medium">Remove</button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm max-w-xl">
              <h3 className="font-medium text-lg mb-4">Invite Team Member</h3>
              <div className="flex items-end gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Email address</label>
                  <input type="email" className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm" placeholder="colleague@company.com" />
                </div>
                <div className="w-1/3">
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Role</label>
                  <select className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm text-foreground">
                    <option>Viewer</option>
                    <option>Analyst</option>
                    <option>Developer</option>
                    <option>Admin</option>
                  </select>
                </div>
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors h-[38px]">Send Invite</button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-secondary/30 border border-border p-4 rounded-lg">
                <h4 className="font-semibold text-sm mb-1 text-primary">Admin</h4>
                <p className="text-xs text-muted-foreground">Full access. Can manage billing, API keys, team, and all settings.</p>
              </div>
              <div className="bg-secondary/30 border border-border p-4 rounded-lg">
                <h4 className="font-semibold text-sm mb-1">Developer</h4>
                <p className="text-xs text-muted-foreground">Can view all data, manage integrations and API keys. Cannot manage billing or team.</p>
              </div>
              <div className="bg-secondary/30 border border-border p-4 rounded-lg">
                <h4 className="font-semibold text-sm mb-1">Analyst</h4>
                <p className="text-xs text-muted-foreground">Can view dashboards, sessions, and reports. Cannot modify config.</p>
              </div>
              <div className="bg-secondary/30 border border-border p-4 rounded-lg">
                <h4 className="font-semibold text-sm mb-1 text-muted-foreground">Viewer</h4>
                <p className="text-xs text-muted-foreground">Read-only access to dashboards and reports only.</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "Privacy & Consent" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2"><Shield className="w-5 h-5" /> Privacy & Consent</h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Configure data collection, retention, and anonymization settings to comply with local regulations.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <h3 className="font-medium text-lg mb-6">Data Collection & Anonymization</h3>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm flex items-center">IP Anonymization <MVPBadge /></div>
                    <div className="text-sm text-muted-foreground">Hash last octet of IP addresses before storage</div>
                  </div>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm flex items-center">Session ID Rotation <MVPBadge /></div>
                    <div className="text-sm text-muted-foreground">Rotate IDs every 24h for GDPR compliance</div>
                  </div>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm flex items-center">Data Residency <EnterpriseBadge /></div>
                    <div className="text-sm text-muted-foreground">Region where data is stored and processed</div>
                  </div>
                  <select className="bg-background border border-border rounded-md px-3 py-1.5 text-sm text-foreground">
                    <option>EU (eu-west-1)</option>
                    <option>US (us-east-1)</option>
                    <option>APAC (ap-southeast-1)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm flex items-center">Right to Erasure <EnterpriseBadge /></div>
                    <div className="text-sm text-muted-foreground">Auto-delete sessions linked to erasure requests via API</div>
                  </div>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>

                <div className="flex items-center justify-between opacity-80">
                  <div>
                    <div className="font-medium text-sm flex items-center">Consent Mode Integration <EnterpriseBadge /></div>
                    <div className="text-sm text-muted-foreground">Only collect data when CMP grants analytics consent</div>
                  </div>
                  <div className="w-10 h-6 bg-secondary rounded-full relative cursor-pointer"><div className="absolute left-1 top-1 w-4 h-4 bg-muted-foreground rounded-full"></div></div>
                </div>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <h3 className="font-medium text-lg mb-6">Data Retention</h3>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between mb-2">
                    <div className="font-medium text-sm">Raw Telemetry Events</div>
                    <div className="text-sm font-mono text-muted-foreground">90 days</div>
                  </div>
                  <input type="range" min="1" max="100" defaultValue="30" className="w-full accent-primary" />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <div className="font-medium text-sm">Session Scores</div>
                    <div className="text-sm font-mono text-muted-foreground">365 days</div>
                  </div>
                  <input type="range" min="1" max="100" defaultValue="60" className="w-full accent-primary" />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <div className="font-medium text-sm">Audit Logs</div>
                    <div className="text-sm font-mono text-muted-foreground">730 days (2 years)</div>
                  </div>
                  <input type="range" min="1" max="100" defaultValue="100" className="w-full accent-primary" />
                </div>
              </div>
            </div>

            <div className="bg-green-500/10 border border-green-500/20 p-4 rounded-lg flex items-start gap-3">
              <div className="p-1 bg-green-500/20 rounded-full mt-0.5"><CheckCircle2 className="w-4 h-4 text-green-500" /></div>
              <div>
                <h4 className="font-medium text-green-500 text-sm">Compliance Verified</h4>
                <p className="text-sm text-green-500/80 mt-1">Compliant with GDPR, CCPA, and PECR as of last audit (Jan 2024). Data processing agreement is active.</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "Audit Log" && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2"><History className="w-5 h-5" /> Audit Log</h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Every action taken in your Proof of Human account is logged here.
              </p>
            </div>

            <div className="flex flex-wrap gap-3 items-center p-4 bg-card border border-border rounded-xl shadow-sm">
              <div className="flex-1 min-w-[250px] relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-muted-foreground" />
                <input type="text" placeholder="Filter by user, action, or resource..." className="w-full bg-background border border-border rounded-md pl-9 pr-3 py-1.5 text-sm" />
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-background border border-border rounded-md text-sm cursor-pointer hover:bg-secondary/50 transition-colors whitespace-nowrap">
                Last 30 days
              </div>
              <button className="px-3 py-1.5 bg-secondary text-secondary-foreground font-medium border border-border rounded-md text-sm hover:bg-secondary/80 transition-colors whitespace-nowrap">
                Export CSV
              </button>
            </div>

            <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/20 text-muted-foreground border-b border-border/50">
                    <tr>
                      <th className="px-6 py-3 text-left font-medium">Timestamp</th>
                      <th className="px-6 py-3 text-left font-medium">User</th>
                      <th className="px-6 py-3 text-left font-medium">Action</th>
                      <th className="px-6 py-3 text-left font-medium">Resource</th>
                      <th className="px-6 py-3 text-left font-medium">IP</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50 font-mono text-xs">
                    {[
                      { ts: "2024-01-15 14:23:01", user: "alice@company.com", act: "api_key.created", res: "prod-key-v3", ip: "192.168.1.42" },
                      { ts: "2024-01-15 13:11:45", user: "bob@company.com", act: "dashboard.viewed", res: "main", ip: "10.0.4.11" },
                      { ts: "2024-01-15 12:44:12", user: "alice@company.com", act: "webhook.updated", res: "slack-hook", ip: "192.168.1.42" },
                      { ts: "2024-01-15 11:02:55", user: "carol@company.com", act: "blocklist.added", res: "IP:104.21.x.x", ip: "172.16.0.5" },
                      { ts: "2024-01-14 16:30:21", user: "alice@company.com", act: "settings.updated", res: "captcha_threshold", ip: "192.168.1.42" },
                      { ts: "2024-01-14 10:15:00", user: "system", act: "model.retrained", res: "v2.4.1", ip: "10.0.0.1" },
                      { ts: "2024-01-13 09:44:33", user: "dan@company.com", act: "report.exported", res: "monthly_fraud", ip: "10.0.5.22" },
                      { ts: "2024-01-12 14:10:11", user: "bob@company.com", act: "fp.confirmed", res: "sess_4a2b", ip: "10.0.4.11" },
                      { ts: "2024-01-11 11:05:44", user: "alice@company.com", act: "team.invited", res: "eve@company.com", ip: "192.168.1.42" },
                      { ts: "2024-01-10 08:30:00", user: "system", act: "billing.invoice.paid", res: "inv_9381", ip: "10.0.0.1" },
                    ].map((row, i) => (
                      <tr key={i} className="hover:bg-muted/5 transition-colors">
                        <td className="px-6 py-3 text-muted-foreground whitespace-nowrap">{row.ts}</td>
                        <td className="px-6 py-3">{row.user}</td>
                        <td className="px-6 py-3 text-primary">{row.act}</td>
                        <td className="px-6 py-3">{row.res}</td>
                        <td className="px-6 py-3 text-muted-foreground">{row.ip}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
