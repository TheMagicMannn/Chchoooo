import { useState, useMemo, Fragment } from 'react';
import { AppLayout } from '@/components/app-layout';
import { Search, Download, ChevronDown, ChevronRight, ChevronLeft, ChevronUp } from 'lucide-react';

const COUNTRIES_L = ['US','UK','DE','IN','BR','CA','FR','AU','NL','SG'];
const EVENTS_L = ['page_view','checkout','form_submit','login','api_call','scroll','click'];
const VERDICTS_L = ['HUMAN','HUMAN','HUMAN','HUMAN','BOT','BOT','CAPTCHA'];
const DOMAINS_L = ['yourstore.com','client-demo.com','staging.yourstore.com'];
function rHex(n: number) { let s=''; const c='0123456789abcdef'; for(let i=0;i<n;i++) s+=c[Math.floor(Math.random()*c.length)]; return s; }
const ALL_LOGS = Array.from({length:120}).map((_,i) => {
  const verdict = VERDICTS_L[Math.floor(Math.random()*VERDICTS_L.length)];
  const score = verdict==='BOT' ? +(Math.random()*0.3).toFixed(3) : verdict==='CAPTCHA' ? +(0.3+Math.random()*0.2).toFixed(3) : +(0.7+Math.random()*0.29).toFixed(3);
  const d = new Date(Date.now() - i*45000);
  const pad = (n: number) => n.toString().padStart(2,'0');
  return {
    id: i, timestamp: pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds()),
    fullTimestamp: d.toISOString().slice(0,19).replace('T',' '),
    session_id: 'sess_'+rHex(6),
    domain: DOMAINS_L[Math.floor(Math.random()*DOMAINS_L.length)],
    event_type: EVENTS_L[Math.floor(Math.random()*EVENTS_L.length)],
    score, verdict,
    country: COUNTRIES_L[Math.floor(Math.random()*COUNTRIES_L.length)],
    duration_ms: Math.floor(Math.random()*800+50),
    ua_hash: rHex(8), ip_hash: rHex(8),
    referrer: ['google.com','direct','facebook.com','email'][Math.floor(Math.random()*4)],
  };
});

export default function Logs() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDomain, setFilterDomain] = useState('all');
  const [filterVerdict, setFilterVerdict] = useState('all');
  const [filterEvent, setFilterEvent] = useState('all');
  const [minScore, setMinScore] = useState('0');
  const [maxScore, setMaxScore] = useState('1');
  const [pageSize, setPageSize] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);
  const [expandedRow, setExpandedRow] = useState<number | null>(null);

  const filtered = useMemo(() => {
    return ALL_LOGS.filter(log => {
      if (filterDomain !== 'all' && log.domain !== filterDomain) return false;
      if (filterVerdict !== 'all' && log.verdict !== filterVerdict) return false;
      if (filterEvent !== 'all' && log.event_type !== filterEvent) return false;
      const mn = parseFloat(minScore)||0, mx = parseFloat(maxScore)||1;
      if (log.score < mn || log.score > mx) return false;
      if (searchQuery && !log.session_id.includes(searchQuery) && !log.domain.includes(searchQuery) && !log.event_type.includes(searchQuery)) return false;
      return true;
    });
  }, [searchQuery, filterDomain, filterVerdict, filterEvent, minScore, maxScore]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const pageItems = filtered.slice((currentPage-1)*pageSize, currentPage*pageSize);

  const clearFilters = () => {
    setSearchQuery('');
    setFilterDomain('all');
    setFilterVerdict('all');
    setFilterEvent('all');
    setMinScore('0');
    setMaxScore('1');
    setCurrentPage(1);
  };

  return (
    <AppLayout>
      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold">Log Explorer</h1>
            <p className="text-muted-foreground text-sm">Immutable event stream</p>
          </div>
          <button className="flex items-center gap-2 px-3 py-1.5 border border-border rounded-md text-sm font-medium hover:bg-secondary">
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>

        <div className="bg-card border border-border rounded-xl p-4 mb-4 flex flex-wrap gap-3 items-end">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="Search session, domain, event..."
              className="w-full bg-secondary border border-border rounded-md pl-9 pr-3 py-2 text-sm outline-none focus:border-primary"
              value={searchQuery}
              onChange={e => { setSearchQuery(e.target.value); setCurrentPage(1); }}
            />
          </div>
          <select 
            className="bg-secondary border border-border rounded-md px-3 py-2 text-sm outline-none"
            value={filterDomain} onChange={e => { setFilterDomain(e.target.value); setCurrentPage(1); }}
          >
            <option value="all">All Domains</option>
            <option value="yourstore.com">yourstore.com</option>
            <option value="client-demo.com">client-demo.com</option>
            <option value="staging.yourstore.com">staging.yourstore.com</option>
          </select>
          <select 
            className="bg-secondary border border-border rounded-md px-3 py-2 text-sm outline-none"
            value={filterEvent} onChange={e => { setFilterEvent(e.target.value); setCurrentPage(1); }}
          >
            <option value="all">All Events</option>
            {EVENTS_L.map(ev => <option key={ev} value={ev}>{ev}</option>)}
          </select>
          <select 
            className="bg-secondary border border-border rounded-md px-3 py-2 text-sm outline-none"
            value={filterVerdict} onChange={e => { setFilterVerdict(e.target.value); setCurrentPage(1); }}
          >
            <option value="all">All Verdicts</option>
            <option value="HUMAN">HUMAN</option>
            <option value="BOT">BOT</option>
            <option value="CAPTCHA">CAPTCHA</option>
          </select>
          <div className="flex items-center gap-2">
            <input 
              type="number" step="0.1" min="0" max="1" 
              placeholder="Min Score" 
              className="bg-secondary border border-border rounded-md px-2 py-2 text-sm outline-none w-20"
              value={minScore} onChange={e => { setMinScore(e.target.value); setCurrentPage(1); }}
            />
            <span className="text-muted-foreground">-</span>
            <input 
              type="number" step="0.1" min="0" max="1" 
              placeholder="Max Score" 
              className="bg-secondary border border-border rounded-md px-2 py-2 text-sm outline-none w-20"
              value={maxScore} onChange={e => { setMaxScore(e.target.value); setCurrentPage(1); }}
            />
          </div>
          <button 
            onClick={clearFilters}
            className="text-sm font-medium text-muted-foreground hover:text-foreground px-2 py-2"
          >
            Clear
          </button>
        </div>

        <div className="flex justify-between items-center mb-2 text-sm text-muted-foreground">
          <div>
            Showing {((currentPage-1)*pageSize) + 1}–{Math.min(currentPage*pageSize, filtered.length)} of {filtered.length} events
          </div>
          <div className="flex items-center gap-2">
            Per page:
            <select 
              className="bg-transparent border border-border rounded-md px-2 py-1 outline-none text-foreground"
              value={pageSize}
              onChange={e => { setPageSize(parseInt(e.target.value)); setCurrentPage(1); }}
            >
              <option value={10}>10</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-muted/10 border-b border-border text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Timestamp</th>
                  <th className="px-4 py-3 font-medium">Session ID</th>
                  <th className="px-4 py-3 font-medium">Domain</th>
                  <th className="px-4 py-3 font-medium">Event</th>
                  <th className="px-4 py-3 font-medium">Score</th>
                  <th className="px-4 py-3 font-medium">Verdict</th>
                  <th className="px-4 py-3 font-medium">Country</th>
                  <th className="px-4 py-3 font-medium">Duration</th>
                  <th className="px-4 py-3 font-medium w-10"></th>
                </tr>
              </thead>
              <tbody>
                {pageItems.map(log => (
                  <Fragment key={log.id}>
                    <tr 
                      className="cursor-pointer hover:bg-secondary/20 border-b border-border/40 transition-colors"
                      onClick={() => setExpandedRow(expandedRow === log.id ? null : log.id)}
                    >
                      <td className="px-4 py-3 text-sm font-mono text-xs text-muted-foreground">{log.timestamp}</td>
                      <td className="px-4 py-3 text-sm font-mono text-xs">{log.session_id}</td>
                      <td className="px-4 py-3 text-sm">{log.domain}</td>
                      <td className="px-4 py-3 text-sm">{log.event_type}</td>
                      <td className={`px-4 py-3 text-sm font-medium ${log.score < 0.3 ? 'text-red-400' : log.score < 0.7 ? 'text-yellow-400' : 'text-green-400'}`}>
                        {log.score.toFixed(3)}
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          log.verdict === 'HUMAN' ? 'bg-green-500/20 text-green-500' : 
                          log.verdict === 'BOT' ? 'bg-red-500/20 text-red-500' : 'bg-yellow-500/20 text-yellow-500'
                        }`}>
                          {log.verdict}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{log.country}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{log.duration_ms}ms</td>
                      <td className="px-4 py-3 text-muted-foreground">
                        {expandedRow === log.id ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </td>
                    </tr>
                    {expandedRow === log.id && (
                      <tr>
                        <td colSpan={9} className="px-4 py-3 bg-muted/5 border-b border-border">
                          <div className="rounded-lg p-4 bg-background grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">Full Timestamp</div>
                              <div className="text-sm font-mono">{log.fullTimestamp}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">UA Hash</div>
                              <div className="text-sm font-mono">{log.ua_hash}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">IP Hash</div>
                              <div className="text-sm font-mono">{log.ip_hash}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">Referrer</div>
                              <div className="text-sm truncate">{log.referrer}</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">Risk Level</div>
                              <div className="text-sm">
                                {log.score < 0.3 ? 'High' : log.score < 0.7 ? 'Medium' : 'Low'}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">Model Version</div>
                              <div className="text-sm">v2.4.1</div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground mb-1">Country</div>
                              <div className="text-sm">{log.country}</div>
                            </div>
                          </div>
                          <div className="flex gap-2 mt-3">
                            <button className="px-3 py-1.5 text-xs font-medium border border-red-500/50 text-red-400 hover:bg-red-500/10 rounded-md transition-colors">
                              Add to Blocklist
                            </button>
                            <button className="px-3 py-1.5 text-xs font-medium border border-border hover:bg-secondary rounded-md transition-colors">
                              Mark False Positive
                            </button>
                            <button className="px-3 py-1.5 text-xs font-medium border border-border hover:bg-secondary rounded-md transition-colors" onClick={() => navigator.clipboard.writeText(log.session_id)}>
                              Copy ID
                            </button>
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex justify-center items-center gap-2 mt-6">
          <button 
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(p => p - 1)}
            className="w-8 h-8 flex items-center justify-center rounded-md border border-border bg-secondary/50 hover:bg-secondary disabled:opacity-50 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          
          {Array.from({length: Math.min(5, totalPages)}).map((_, i) => {
            let pageNum = currentPage;
            if (currentPage < 3) pageNum = i + 1;
            else if (currentPage > totalPages - 2) pageNum = totalPages - 4 + i;
            else pageNum = currentPage - 2 + i;
            
            if (pageNum < 1 || pageNum > totalPages) return null;
            
            return (
              <button
                key={pageNum}
                onClick={() => setCurrentPage(pageNum)}
                className={`w-8 h-8 rounded-md text-sm font-medium transition-colors ${
                  currentPage === pageNum 
                    ? 'bg-primary text-primary-foreground' 
                    : 'bg-secondary/50 text-muted-foreground hover:bg-secondary'
                }`}
              >
                {pageNum}
              </button>
            )
          })}

          <button 
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage(p => p + 1)}
            className="w-8 h-8 flex items-center justify-center rounded-md border border-border bg-secondary/50 hover:bg-secondary disabled:opacity-50 transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </AppLayout>
  );
}