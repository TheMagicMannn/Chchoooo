import { useState } from "react";
import { AppLayout } from "@/components/app-layout";
import { CodeBlock } from "@/components/code-block";
import { SiGoogleanalytics, SiShopify, SiGoogletagmanager, SiWordpress } from "react-icons/si";
import { CheckCircle2, Webhook, KeyRound, Copy, Download } from "lucide-react";

export default function Integrations() {
  const [activeTab, setActiveTab] = useState("GA4");
  const tabs = ["GA4", "GTM", "WordPress", "Shopify", "Webhooks", "API Keys"];

  const MVPBadge = () => <span className="text-xs font-mono bg-primary/20 text-primary px-1.5 py-0.5 rounded ml-2">MVP</span>;

  const gtmLines = [
    '<script>',
    '(function() {',
    '  window.PoH = { token: "poh_live_****8a3f", sessionId: crypto.randomUUID() };',
    '  var s = document.createElement("script");',
    '  s.src = "https://cdn.proofofhuman.io/sdk/v2.min.js";',
    '  s.async = true;',
    '  document.head.appendChild(s);',
    '})();',
    '<\\/script>'
  ];
  const gtmCode = gtmLines.join('\\n');

  const ga4Code = `{
  "client_id": "1234567890.1700000000",
  "events": [{
    "name": "page_view",
    "params": {
      "page_location": "https://yourstore.com/checkout",
      "poh_session_id": "sess_8f3a2c",
      "poh_human_score": 0.91,
      "poh_verdict": "HUMAN",
      "poh_model_version": "v2.4.1"
    }
  }]
}`;

  const webhookPayload = `{
  "event": "session_blocked",
  "timestamp": "2024-01-15T14:23:00Z",
  "site": "yourstore.com",
  "session_id": "sess_8f3a2c",
  "human_score": 0.08,
  "verdict": "BOT",
  "action": "blocked",
  "trigger_rule": "score_threshold",
  "cluster_id": "cluster_a"
}`;

  return (
    <AppLayout>
      <div className="p-6 md:p-10 max-w-5xl mx-auto w-full">
        <h1 className="text-3xl font-bold mb-6">Integrations & API</h1>
        
        <div className="flex overflow-x-auto space-x-2 border-b border-border/40 mb-8 pb-px hide-scrollbar">
          {tabs.map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === t
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t} <MVPBadge />
            </button>
          ))}
        </div>

        {activeTab === "GA4" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div className="flex items-center justify-between bg-card border border-border p-6 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-[#e37400]/10 rounded-lg">
                  <SiGoogleanalytics className="w-8 h-8 text-[#e37400]" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">Google Analytics 4</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    <span className="text-sm text-green-500 font-medium">Connected to property: GA4-DEMO-12345</span>
                  </div>
                </div>
              </div>
              <button className="px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-secondary transition-colors">Disconnect</button>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <h3 className="font-medium text-lg mb-6">Configuration</h3>
              <div className="space-y-6 max-w-2xl">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm">Send human_score as custom dimension</div>
                    <div className="text-sm text-muted-foreground">Appends poh_human_score to all tracked events</div>
                  </div>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm">Send verdict (HUMAN/BOT) as event parameter</div>
                    <div className="text-sm text-muted-foreground">Simplifies filtering in GA4 Explorer</div>
                  </div>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>

                <div className="flex items-center justify-between opacity-80">
                  <div>
                    <div className="font-medium text-sm">Enrich conversion events only</div>
                    <div className="text-sm text-muted-foreground">Limits API usage by only scoring checkout/signup events</div>
                  </div>
                  <div className="w-10 h-6 bg-secondary rounded-full relative cursor-pointer"><div className="absolute left-1 top-1 w-4 h-4 bg-muted-foreground rounded-full"></div></div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm">Exclude bot sessions from GA4 entirely</div>
                    <div className="text-sm text-muted-foreground">Prevents tracking calls when score &lt; threshold</div>
                  </div>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-medium text-lg mb-4">GA4 Admin Setup Instructions</h3>
              <div className="bg-secondary/30 border border-border p-4 rounded-lg text-sm mb-4">
                Add these custom dimensions in GA4 → Admin → Custom definitions to see the data in your reports:
                <ul className="list-disc pl-5 mt-2 space-y-1 text-muted-foreground">
                  <li><span className="font-mono text-foreground">poh_human_score</span> (Scope: Event, Type: Number)</li>
                  <li><span className="font-mono text-foreground">poh_verdict</span> (Scope: Event, Type: Text)</li>
                  <li><span className="font-mono text-foreground">poh_session_id</span> (Scope: Event, Type: Text)</li>
                </ul>
              </div>
              <h4 className="text-sm font-medium text-muted-foreground mb-2">Sample Payload Preview</h4>
              <CodeBlock code={ga4Code} language="json" />
            </div>
          </div>
        )}

        {activeTab === "GTM" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div className="flex items-center justify-between bg-card border border-border p-6 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-[#246FDB]/10 rounded-lg">
                  <SiGoogletagmanager className="w-8 h-8 text-[#246FDB]" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">Google Tag Manager</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    <span className="text-sm text-green-500 font-medium">Container: GTM-X8K2P</span>
                  </div>
                </div>
              </div>
              <button className="px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-secondary transition-colors">Disconnect</button>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <h3 className="font-medium text-lg mb-4">Installation Steps</h3>
              <ol className="list-decimal pl-5 space-y-2 text-sm text-muted-foreground mb-6">
                <li>Open Google Tag Manager → Tags → New</li>
                <li>Select tag type: Custom HTML</li>
                <li>Paste the snippet below. Set trigger: All Pages.</li>
                <li>Click Submit to publish your container.</li>
              </ol>
              
              <div className="relative group my-4">
                <pre className="bg-background border border-border rounded-lg p-4 text-xs font-mono text-green-400 overflow-x-auto whitespace-pre">{gtmCode}</pre>
                <button 
                  onClick={() => navigator.clipboard.writeText(gtmCode)}
                  className="absolute top-2 right-2 p-1.5 bg-secondary/80 border border-border rounded hover:bg-secondary text-muted-foreground"
                  title="Copy code"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-6 mt-8 max-w-2xl border-t border-border pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm text-foreground">Track all page views automatically</div>
                  </div>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm text-foreground">Include scroll depth events</div>
                  </div>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>
                <div className="flex items-center justify-between opacity-80">
                  <div>
                    <div className="font-medium text-sm text-foreground">Send data layer push events</div>
                  </div>
                  <div className="w-10 h-6 bg-secondary rounded-full relative cursor-pointer"><div className="absolute left-1 top-1 w-4 h-4 bg-muted-foreground rounded-full"></div></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "WordPress" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div className="flex items-center justify-between bg-card border border-border p-6 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-[#21759b]/10 rounded-lg">
                  <SiWordpress className="w-8 h-8 text-[#21759b]" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">WordPress</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    <span className="text-sm text-green-500 font-medium">Plugin version: 1.4.2</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
                <h3 className="font-medium text-lg mb-4">Installation</h3>
                <ol className="list-decimal pl-5 space-y-2 text-sm text-muted-foreground mb-6">
                  <li>Download the plugin zip from the button below.</li>
                  <li>wp-admin → Plugins → Add New → Upload Plugin</li>
                  <li>Upload proof-of-human.zip and click Install Now.</li>
                  <li>Activate the plugin.</li>
                  <li>Go to Settings → Proof of Human → paste your API token.</li>
                  <li>Click Save Changes. Detection begins immediately.</li>
                </ol>
                <button className="flex items-center gap-2 px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-secondary transition-colors">
                  <Download className="w-4 h-4" /> Download Plugin (v1.4.2)
                </button>

                <div className="space-y-6 mt-8 max-w-2xl border-t border-border pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm text-foreground">Block bot checkouts automatically</div>
                    </div>
                    <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm text-foreground">Log scored sessions to wp_poh_sessions table</div>
                    </div>
                    <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                  </div>
                  <div className="flex items-center justify-between opacity-80">
                    <div>
                      <div className="font-medium text-sm text-foreground">Show admin bar bot rate indicator</div>
                    </div>
                    <div className="w-10 h-6 bg-secondary rounded-full relative cursor-pointer"><div className="absolute left-1 top-1 w-4 h-4 bg-muted-foreground rounded-full"></div></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium text-sm text-foreground">Exclude logged-in users from scoring</div>
                    </div>
                    <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium text-lg mb-4 text-muted-foreground">Admin Settings Mockup</h3>
                <div className="bg-[#1d2327] border border-[#3c434a] rounded-lg overflow-hidden w-full max-w-md text-sm shadow-xl">
                  <div className="bg-[#23282d] px-4 py-2 text-[#a7aaad] text-xs font-medium">
                    Settings › Proof of Human
                  </div>
                  <div className="p-4 space-y-4 text-gray-200">
                    <div>
                      <label className="block text-xs mb-1 text-gray-300">API Token</label>
                      <input 
                        type="text" 
                        value="poh_live_****8a3f" 
                        readOnly 
                        className="w-full bg-white border border-[#8c8f94] text-gray-800 rounded px-3 py-1.5 text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs mb-1 text-gray-300">Detection Mode</label>
                      <select className="w-full bg-white border border-[#8c8f94] text-gray-800 rounded px-3 py-1.5 text-sm">
                        <option>Standard (Recommended)</option>
                        <option>Aggressive (Higher CAPTCHA rate)</option>
                        <option>Passive (Monitoring only)</option>
                      </select>
                    </div>
                    <div className="pt-2">
                      <button className="bg-[#2271b1] text-white text-xs px-3 py-1.5 rounded font-medium hover:bg-[#135e96]">
                        Save Changes
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "Shopify" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div className="flex items-center justify-between bg-card border border-border p-6 rounded-xl shadow-sm">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-[#96bf48]/10 rounded-lg">
                  <SiShopify className="w-8 h-8 text-[#96bf48]" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold">Shopify</h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    <span className="text-sm text-green-500 font-medium">Connected to: mystore.myshopify.com</span>
                  </div>
                </div>
              </div>
              <button className="px-4 py-2 border border-border rounded-md text-sm font-medium hover:bg-secondary transition-colors">App Settings</button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-medium text-lg">Bot Checkout Blocking</h3>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>
                <p className="text-sm text-muted-foreground">Blocks orders where human_score &lt; 0.4 before Shopify processes payment. Saves payment gateway fees.</p>
              </div>
              
              <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-medium text-lg">Order Enrichment</h3>
                  <div className="w-10 h-6 bg-primary rounded-full relative cursor-pointer"><div className="absolute right-1 top-1 w-4 h-4 bg-primary-foreground rounded-full"></div></div>
                </div>
                <p className="text-sm text-muted-foreground">Adds poh_score to order metafields for reporting and downstream fulfillment workflows.</p>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <h3 className="font-medium text-lg mb-2">Recent Blocked Checkouts</h3>
              <p className="text-sm text-muted-foreground mb-6">Events subscribed: orders/create, checkouts/create, customers/create</p>
              
              <div className="bg-red-500/5 border border-red-500/20 rounded-lg p-4 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium">Order #8821</span>
                    <span className="text-sm text-muted-foreground">— $247.00</span>
                    <span className="bg-red-500/20 text-red-500 text-xs px-2 py-0.5 rounded font-bold">Blocked (score: 0.08)</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Saved from fraudulent checkout. Cart contained 3 high-value electronics.</p>
                </div>
                <span className="text-sm text-muted-foreground">2 min ago</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === "Webhooks" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2"><Webhook className="w-6 h-6" /> Webhook Configuration</h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Send real-time events to your own endpoints when Proof of Human takes action.
              </p>
            </div>

            <div className="space-y-4">
              <h3 className="font-medium text-lg">Active Webhooks</h3>
              {[
                { url: "https://hooks.yourstore.com/poh-alerts", events: "block, flag, cluster_detected", last: "2 min ago", status: "Healthy" },
                { url: "https://your-crm.com/webhooks/poh", events: "block", last: "18 min ago", status: "Healthy" },
                { url: "https://slack-webhook.example.com/...", events: "critical_alert", last: "1 hr ago", status: "Healthy" },
              ].map((hook, i) => (
                <div key={i} className="bg-card border border-border p-4 rounded-xl shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <div className="font-medium font-mono text-sm mb-1">{hook.url}</div>
                    <div className="text-sm text-muted-foreground">Events: {hook.events}</div>
                  </div>
                  <div className="flex items-center gap-6 shrink-0">
                    <div className="text-sm text-muted-foreground text-right">
                      <div>Last fired: {hook.last}</div>
                      <div className="text-green-500 font-medium">Status: {hook.status}</div>
                    </div>
                    <button className="text-muted-foreground hover:text-foreground text-sm font-medium">Edit</button>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
              <h3 className="font-medium text-lg mb-4">Add Webhook Endpoint</h3>
              <div className="space-y-4 max-w-xl">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Payload URL</label>
                  <input type="text" className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm" placeholder="https://" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Events to send</label>
                  <div className="grid grid-cols-2 gap-2">
                    <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" className="rounded border-border bg-background" checked readOnly /> block</label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" className="rounded border-border bg-background" checked readOnly /> flag</label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" className="rounded border-border bg-background" checked readOnly /> cluster_detected</label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" className="rounded border-border bg-background" /> model_retrain</label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" className="rounded border-border bg-background" /> critical_alert</label>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Secret (for HMAC signature)</label>
                  <input type="password" className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm" placeholder="whsec_..." />
                </div>
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">Save Endpoint</button>
              </div>
            </div>

            <div>
              <h3 className="font-medium text-lg mb-4">Example Payload</h3>
              <CodeBlock code={webhookPayload} language="json" />
            </div>
          </div>
        )}

        {activeTab === "API Keys" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold flex items-center gap-2"><KeyRound className="w-6 h-6" /> API Key Management</h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Use API keys to authenticate requests to the Proof of Human API from your backend.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-border bg-muted/20 flex justify-between items-center">
                <h3 className="font-medium">Active Keys</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/10 text-muted-foreground">
                    <tr>
                      <th className="px-6 py-3 text-left font-medium">Name</th>
                      <th className="px-6 py-3 text-left font-medium">Key</th>
                      <th className="px-6 py-3 text-left font-medium">Created</th>
                      <th className="px-6 py-3 text-left font-medium">Last Used</th>
                      <th className="px-6 py-3 text-left font-medium">Permissions</th>
                      <th className="px-6 py-3 text-left font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    <tr className="hover:bg-muted/5">
                      <td className="px-6 py-4 font-medium">Production</td>
                      <td className="px-6 py-4 font-mono text-xs">poh_live_****8a3f</td>
                      <td className="px-6 py-4 text-muted-foreground">Jan 1, 2024</td>
                      <td className="px-6 py-4 text-muted-foreground">2 min ago</td>
                      <td className="px-6 py-4"><span className="bg-secondary px-2 py-1 rounded text-xs">read, write</span></td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button className="text-xs font-medium text-muted-foreground hover:text-foreground">Rotate</button>
                          <button className="text-xs font-medium text-red-500 hover:text-red-400">Revoke</button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-muted/5">
                      <td className="px-6 py-4 font-medium">Staging</td>
                      <td className="px-6 py-4 font-mono text-xs text-muted-foreground">poh_test_****2b1c</td>
                      <td className="px-6 py-4 text-muted-foreground">Dec 15, 2023</td>
                      <td className="px-6 py-4 text-muted-foreground">3 days ago</td>
                      <td className="px-6 py-4"><span className="bg-secondary px-2 py-1 rounded text-xs">read</span></td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button className="text-xs font-medium text-muted-foreground hover:text-foreground">Rotate</button>
                          <button className="text-xs font-medium text-red-500 hover:text-red-400">Revoke</button>
                        </div>
                      </td>
                    </tr>
                    <tr className="hover:bg-muted/5">
                      <td className="px-6 py-4 font-medium">Analytics Export</td>
                      <td className="px-6 py-4 font-mono text-xs">poh_live_****9f4e</td>
                      <td className="px-6 py-4 text-muted-foreground">Nov 28, 2023</td>
                      <td className="px-6 py-4 text-muted-foreground">1 hr ago</td>
                      <td className="px-6 py-4"><span className="bg-secondary px-2 py-1 rounded text-xs">read</span></td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2">
                          <button className="text-xs font-medium text-muted-foreground hover:text-foreground">Rotate</button>
                          <button className="text-xs font-medium text-red-500 hover:text-red-400">Revoke</button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm max-w-xl">
              <h3 className="font-medium text-lg mb-4">Create New API Key</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Key Name</label>
                  <input type="text" className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm" placeholder="e.g. CI/CD Pipeline" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-2">Permissions</label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" className="rounded border-border bg-background" checked readOnly /> read</label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" className="rounded border-border bg-background" /> write</label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer"><input type="checkbox" className="rounded border-border bg-background" /> admin</label>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-muted-foreground mb-1">Expiry</label>
                  <select className="w-full bg-background border border-border rounded-md px-3 py-2 text-sm text-foreground">
                    <option>Never</option>
                    <option>30 days</option>
                    <option>90 days</option>
                    <option>1 year</option>
                  </select>
                </div>
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">Create Key</button>
              </div>
            </div>

            <div>
              <h3 className="font-medium text-lg mb-4">API Endpoint Reference</h3>
              <ul className="space-y-2 font-mono text-sm">
                <li className="flex gap-4"><span className="text-blue-400 w-12">GET</span> <span>/v1/sessions</span> <span className="text-muted-foreground hidden md:inline">— List sessions with scores</span></li>
                <li className="flex gap-4"><span className="text-green-400 w-12">POST</span> <span>/v1/infer</span> <span className="text-muted-foreground hidden md:inline">— Run inference on a feature vector</span></li>
                <li className="flex gap-4"><span className="text-blue-400 w-12">GET</span> <span>/v1/metrics</span> <span className="text-muted-foreground hidden md:inline">— Prometheus-format metrics</span></li>
                <li className="flex gap-4"><span className="text-green-400 w-12">POST</span> <span>/v1/blocklist</span> <span className="text-muted-foreground hidden md:inline">— Add session or IP to blocklist</span></li>
                <li className="flex gap-4"><span className="text-blue-400 w-12">GET</span> <span>/v1/audit</span> <span className="text-muted-foreground hidden md:inline">— Retrieve audit log entries</span></li>
              </ul>
            </div>
          </div>
        )}

      </div>
    </AppLayout>
  );
}
