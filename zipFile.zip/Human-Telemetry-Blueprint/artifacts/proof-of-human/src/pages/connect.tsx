import { useState, useEffect, useMemo } from 'react';
import { AppLayout } from '@/components/app-layout';
import { ChevronDown, Filter, X, RefreshCw, Globe, MessageSquare, Calendar } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { SiGoogleanalytics, SiWoocommerce } from 'react-icons/si';

const TIME_RANGES = ['1m','5m','15m','1h','6h','24h','7d','30d','3M','12M'];

function makeChartData(range: string) {
  if (range === '1m') return [{t:'0s',human:12,bot:2},{t:'15s',human:8,bot:1},{t:'30s',human:15,bot:3},{t:'45s',human:11,bot:2},{t:'60s',human:9,bot:1}];
  if (range === '5m') return [{t:'0:00',human:45,bot:8},{t:'1:00',human:38,bot:6},{t:'2:00',human:52,bot:11},{t:'3:00',human:41,bot:7},{t:'4:00',human:48,bot:9},{t:'5:00',human:44,bot:8}];
  if (range === '15m') return [{t:'0m',human:120,bot:18},{t:'3m',human:98,bot:14},{t:'6m',human:145,bot:24},{t:'9m',human:112,bot:19},{t:'12m',human:128,bot:21},{t:'15m',human:135,bot:20}];
  if (range === '1h') return [{t:'0:00',human:420,bot:62},{t:'15:00',human:380,bot:58},{t:'30:00',human:510,bot:84},{t:'45:00',human:445,bot:71},{t:'60:00',human:480,bot:74}];
  if (range === '6h') return [{t:'0h',human:1200,bot:180},{t:'1h',human:980,bot:145},{t:'2h',human:1420,bot:220},{t:'3h',human:1100,bot:165},{t:'4h',human:1350,bot:198},{t:'5h',human:1280,bot:189},{t:'6h',human:1310,bot:195}];
  if (range === '24h') return [{t:'0h',human:800,bot:120},{t:'4h',human:400,bot:60},{t:'8h',human:1200,bot:180},{t:'12h',human:1800,bot:280},{t:'16h',human:2100,bot:320},{t:'20h',human:1600,bot:240},{t:'24h',human:1200,bot:180}];
  if (range === '30d') return [{t:'Jan 1',human:18000,bot:2800},{t:'Jan 8',human:19200,bot:2950},{t:'Jan 15',human:21400,bot:3100},{t:'Jan 22',human:20800,bot:2900},{t:'Jan 29',human:22100,bot:3300}];
  if (range === '3M') return [{t:'Oct',human:58000,bot:8800},{t:'Nov',human:62000,bot:9400},{t:'Dec',human:71000,bot:10200},{t:'Jan',human:75000,bot:11100}];
  if (range === '12M') return [{t:'Feb',human:42000,bot:6200},{t:'May',human:55000,bot:8300},{t:'Aug',human:61000,bot:9200},{t:'Nov',human:68000,bot:10100},{t:'Jan',human:75000,bot:11100}];
  return [{t:'Mon',human:2100,bot:320},{t:'Tue',human:1950,bot:280},{t:'Wed',human:2400,bot:410},{t:'Thu',human:2300,bot:350},{t:'Fri',human:2200,bot:390},{t:'Sat',human:1800,bot:210},{t:'Sun',human:1850,bot:250}];
}

const DOMAINS = ['All Domains', 'yourstore.com', 'client-demo.com'];
const EVENT_TYPES = ['All Events', 'page_view', 'checkout', 'form_submit', 'login', 'api_call'];
const VERDICTS = ['All', 'HUMAN', 'BOT', 'CAPTCHA'];
const GEO_DATA = [
  { country: 'United States', sessions: 6821, humanRate: '91%' },
  { country: 'United Kingdom', sessions: 1243, humanRate: '88%' },
  { country: 'Germany', sessions: 894, humanRate: '86%' },
  { country: 'India', sessions: 2109, humanRate: '72%' },
  { country: 'Brazil', sessions: 734, humanRate: '69%' },
];
const initialSessions = [
  { time: 'Just now', id: 'sess_a8f2', domain: 'yourstore.com', score: 0.91, verdict: 'HUMAN', event: 'checkout' },
  { time: '2s ago', id: 'sess_b38x', domain: 'yourstore.com', score: 0.84, verdict: 'HUMAN', event: 'page_view' },
  { time: '5s ago', id: 'sess_x99z', domain: 'client-demo.com', score: 0.03, verdict: 'BOT', event: 'form_submit' },
  { time: '12s ago', id: 'sess_m11c', domain: 'yourstore.com', score: 0.95, verdict: 'HUMAN', event: 'login' },
  { time: '15s ago', id: 'sess_p44q', domain: 'client-demo.com', score: 0.12, verdict: 'BOT', event: 'checkout' },
];

const Sparkline = ({ data, color }: { data: any[], color: string }) => (
  <div className="h-10 w-full mt-2">
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={data}>
        <Line type="monotone" dataKey="val" stroke={color} strokeWidth={2} dot={false} isAnimationActive={false} />
      </LineChart>
    </ResponsiveContainer>
  </div>
);

export default function Connect() {
  const [selectedRange, setSelectedRange] = useState('7d');
  const [showFilters, setShowFilters] = useState(false);
  const [domainFilter, setDomainFilter] = useState('All Domains');
  const [eventFilter, setEventFilter] = useState('All Events');
  const [verdictFilter, setVerdictFilter] = useState('All');
  const [minScore, setMinScore] = useState('0');
  const [maxScore, setMaxScore] = useState('1');
  const [drillTarget, setDrillTarget] = useState<{t:string,human:number,bot:number} | null>(null);
  
  const [sessionsAnalyzed, setSessionsAnalyzed] = useState(14823);
  const [botsBlocked, setBotsBlocked] = useState(1872);
  const [recentSessions, setRecentSessions] = useState(initialSessions);
  const [showDomainDrop, setShowDomainDrop] = useState(false);

  const [spark1] = useState(() => Array.from({length:10}).map(() => ({val: Math.random()*10+50})));
  const [spark2] = useState(() => Array.from({length:10}).map(() => ({val: Math.random()*5+85})));
  const [spark3] = useState(() => Array.from({length:10}).map(() => ({val: Math.random()*8+20})));
  const [spark4] = useState(() => Array.from({length:10}).map(() => ({val: Math.random()*0.1+0.85})));

  const chartData = useMemo(() => makeChartData(selectedRange), [selectedRange]);
  const isFiltered = domainFilter !== 'All Domains' || eventFilter !== 'All Events' || verdictFilter !== 'All' || minScore !== '0' || maxScore !== '1';

  useEffect(() => {
    const interval = setInterval(() => {
      setSessionsAnalyzed(prev => prev + Math.floor(Math.random() * 5 + 1));
      setBotsBlocked(prev => prev + (Math.random() > 0.7 ? 1 : 0));
      
      setRecentSessions(prev => {
        const isBot = Math.random() > 0.8;
        const newSession = {
          time: 'Just now',
          id: 'sess_' + Math.random().toString(36).substring(2, 6),
          domain: Math.random() > 0.5 ? 'yourstore.com' : 'client-demo.com',
          score: isBot ? Math.random() * 0.3 : 0.8 + Math.random() * 0.19,
          verdict: isBot ? 'BOT' : 'HUMAN',
          event: ['page_view', 'checkout', 'form_submit', 'login'][Math.floor(Math.random() * 4)]
        };
        const updated = [newSession, ...prev.slice(0, 4)];
        return updated.map((s, i) => {
          if (i === 0) return s;
          if (i === 1) return { ...s, time: '2s ago' };
          if (i === 2) return { ...s, time: '5s ago' };
          if (i === 3) return { ...s, time: '12s ago' };
          return { ...s, time: '15s ago' };
        });
      });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <AppLayout>
      <div className="p-6 max-w-full">
        {/* SECTION 1 */}
        <div className="flex justify-between items-start mb-4 flex-wrap gap-3">
          <div className="flex items-center flex-wrap gap-2">
            <div className="relative">
              <button 
                onClick={() => setShowDomainDrop(!showDomainDrop)}
                className="bg-secondary px-3 py-1.5 rounded-full text-sm flex items-center gap-2"
              >
                {domainFilter} <ChevronDown className="w-3 h-3" />
              </button>
              {showDomainDrop && (
                <div className="absolute top-full mt-1 left-0 bg-card border border-border rounded-lg shadow-lg z-10 w-48 overflow-hidden">
                  {DOMAINS.map(d => (
                    <div 
                      key={d} 
                      className="px-4 py-2 hover:bg-secondary cursor-pointer text-sm"
                      onClick={() => { setDomainFilter(d); setShowDomainDrop(false); }}
                    >
                      {d}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex gap-1 flex-wrap">
              {TIME_RANGES.map(range => (
                <button
                  key={range}
                  onClick={() => { setSelectedRange(range); setDrillTarget(null); }}
                  className={`text-xs px-2 py-1 rounded-md font-mono transition-colors ${
                    selectedRange === range 
                      ? 'bg-primary text-primary-foreground font-medium' 
                      : 'bg-secondary/50 text-muted-foreground hover:bg-secondary'
                  }`}
                >
                  {range}
                </button>
              ))}
              <button
                onClick={() => { setSelectedRange('custom'); setDrillTarget(null); }}
                className={`text-xs px-2 py-1 rounded-md font-mono transition-colors flex items-center gap-1 ${
                  selectedRange === 'custom' 
                    ? 'bg-primary text-primary-foreground font-medium' 
                    : 'bg-secondary/50 text-muted-foreground hover:bg-secondary'
                }`}
              >
                <Calendar className="w-3 h-3" /> Custom
              </button>
            </div>
            
            {selectedRange === 'custom' && (
              <div className="flex items-center gap-1">
                <input type="date" className="bg-secondary border border-border rounded px-2 py-1 text-xs" />
                <span className="text-muted-foreground text-xs">-</span>
                <input type="date" className="bg-secondary border border-border rounded px-2 py-1 text-xs" />
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="px-3 py-1.5 border border-border rounded-md text-sm font-medium flex items-center gap-2 relative hover:bg-secondary transition-colors"
            >
              {showFilters ? <X className="w-4 h-4" /> : <Filter className="w-4 h-4" />}
              Filters
              {isFiltered && <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-cyan-400 rounded-full border border-card"></div>}
            </button>
            <button className="p-2 text-muted-foreground hover:text-foreground hover:bg-secondary rounded-md transition-colors">
              <RefreshCw className="w-4 h-4" />
            </button>
            <button className="bg-primary text-primary-foreground px-3 py-1.5 rounded-md text-sm font-medium hover:bg-primary/90 transition-colors">
              Upgrade to Pro
            </button>
          </div>
        </div>

        {/* SECTION 2 */}
        {showFilters && (
          <div className="bg-card border border-border rounded-xl p-4 mb-4 transition-all duration-200">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-2">Domain</label>
                <select 
                  className="w-full bg-secondary border border-border rounded-md px-3 py-1.5 text-sm outline-none focus:border-primary"
                  value={domainFilter}
                  onChange={e => setDomainFilter(e.target.value)}
                >
                  {DOMAINS.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-2">Event Type</label>
                <select 
                  className="w-full bg-secondary border border-border rounded-md px-3 py-1.5 text-sm outline-none focus:border-primary"
                  value={eventFilter}
                  onChange={e => setEventFilter(e.target.value)}
                >
                  {EVENT_TYPES.map(e => <option key={e} value={e}>{e}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-2">Verdict</label>
                <div className="flex gap-1 flex-wrap">
                  {VERDICTS.map(v => (
                    <button
                      key={v}
                      onClick={() => setVerdictFilter(v)}
                      className={`text-xs px-2 py-1 rounded-md transition-colors ${
                        verdictFilter === v 
                          ? 'bg-primary/20 text-primary border border-primary/30 font-medium' 
                          : 'bg-secondary text-muted-foreground border border-transparent'
                      }`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-2">Score Range</label>
                <div className="flex items-center gap-2">
                  <input 
                    type="number" 
                    min="0" max="1" step="0.1" 
                    value={minScore} 
                    onChange={e => setMinScore(e.target.value)}
                    className="w-full bg-secondary border border-border rounded-md px-2 py-1.5 text-sm outline-none"
                    placeholder="Min"
                  />
                  <input 
                    type="number" 
                    min="0" max="1" step="0.1" 
                    value={maxScore} 
                    onChange={e => setMaxScore(e.target.value)}
                    className="w-full bg-secondary border border-border rounded-md px-2 py-1.5 text-sm outline-none"
                    placeholder="Max"
                  />
                </div>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <button className="bg-primary text-primary-foreground px-3 py-1.5 rounded-md text-sm font-medium hover:bg-primary/90">
                Apply Filters
              </button>
              <button 
                onClick={() => {
                  setDomainFilter('All Domains');
                  setEventFilter('All Events');
                  setVerdictFilter('All');
                  setMinScore('0');
                  setMaxScore('1');
                }}
                className="px-3 py-1.5 rounded-md text-sm font-medium hover:bg-secondary border border-border text-muted-foreground"
              >
                Reset
              </button>
            </div>
          </div>
        )}

        {/* SECTION 3 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
            <div className="text-sm font-medium text-muted-foreground mb-1">Sessions Analyzed</div>
            <div className="text-2xl font-bold">
              {sessionsAnalyzed.toLocaleString()} 
              <span className="text-xs font-normal text-muted-foreground/60 ml-2">{selectedRange}</span>
            </div>
            <Sparkline data={spark1} color="#888888" />
          </div>
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
            <div className="text-sm font-medium text-muted-foreground mb-1">Human Rate</div>
            <div className="text-2xl font-bold text-green-500">
              87.4% 
              <span className="text-xs font-normal text-muted-foreground/60 ml-2">{selectedRange}</span>
            </div>
            <Sparkline data={spark2} color="#22c55e" />
          </div>
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
            <div className="text-sm font-medium text-muted-foreground mb-1">Bots Blocked</div>
            <div className="text-2xl font-bold">
              {botsBlocked.toLocaleString()}
              <span className="text-xs font-normal text-muted-foreground/60 ml-2">{selectedRange}</span>
            </div>
            <Sparkline data={spark3} color="#888888" />
          </div>
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
            <div className="text-sm font-medium text-muted-foreground mb-1">Avg Score</div>
            <div className="text-2xl font-bold text-cyan-400">
              0.91
              <span className="text-xs font-normal text-muted-foreground/60 ml-2">{selectedRange}</span>
            </div>
            <Sparkline data={spark4} color="#22d3ee" />
          </div>
        </div>

        {/* SECTION 4 */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm mb-4">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold">Traffic Quality <span className="text-muted-foreground text-sm font-normal">{' \u00b7 ' + selectedRange + ' view'}</span></h3>
            <div className="flex gap-4">
              <div className="flex items-center gap-1.5 text-sm">
                <div className="w-2 h-2 rounded-full bg-primary"></div> Human
              </div>
              <div className="flex items-center gap-1.5 text-sm">
                <div className="w-2 h-2 rounded-full bg-red-500"></div> Bot
              </div>
            </div>
          </div>
          <div className="h-64 w-full cursor-crosshair">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart 
                data={chartData} 
                margin={{ top: 5, right: 5, bottom: 5, left: -20 }}
                onClick={(data: any) => { 
                  if (data && data.activePayload && data.activePayload[0]) { 
                    setDrillTarget(data.activePayload[0].payload); 
                  } 
                }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                <XAxis dataKey="t" stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#666" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111827', border: '1px solid #333', borderRadius: '8px' }}
                  itemStyle={{ fontWeight: 500 }}
                />
                <Area name="Human" type="monotone" dataKey="human" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.08} />
                <Area name="Bot" type="monotone" dataKey="bot" stroke="#ef4444" fill="#ef4444" fillOpacity={0.08} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* SECTION 5 */}
        {drillTarget && (
          <div className="bg-card border border-primary/30 rounded-xl p-4 mb-4 animate-in fade-in shadow-lg shadow-primary/5">
            <div className="flex justify-between items-center mb-4">
              <span className="font-medium text-sm">
                Drill-down: {drillTarget.t} — {drillTarget.human} human, {drillTarget.bot} bot
              </span>
              <button onClick={() => setDrillTarget(null)} className="text-muted-foreground hover:text-foreground">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs uppercase text-muted-foreground bg-muted/20">
                  <tr>
                    <th className="px-4 py-2">Session</th>
                    <th className="px-4 py-2">Score</th>
                    <th className="px-4 py-2">Verdict</th>
                    <th className="px-4 py-2">Event</th>
                    <th className="px-4 py-2">Country</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {Array.from({length: 5}).map((_, i) => {
                    const isBot = Math.random() < ((drillTarget.bot) / (drillTarget.bot + drillTarget.human) * 2);
                    const score = isBot ? Math.random() * 0.3 : 0.7 + Math.random() * 0.29;
                    const verdict = isBot ? 'BOT' : 'HUMAN';
                    const country = GEO_DATA[Math.floor(Math.random() * GEO_DATA.length)].country;
                    const event = EVENT_TYPES[Math.floor(Math.random() * (EVENT_TYPES.length - 1)) + 1];
                    return (
                      <tr key={i} className="hover:bg-secondary/20">
                        <td className="px-4 py-2 font-mono text-xs">sess_{Math.random().toString(36).substring(2,6)}</td>
                        <td className={`px-4 py-2 ${score < 0.3 ? 'text-red-400' : 'text-green-400'}`}>{score.toFixed(3)}</td>
                        <td className="px-4 py-2">
                          <span className={`px-2 py-0.5 rounded text-xs font-semibold ${verdict === 'HUMAN' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                            {verdict}
                          </span>
                        </td>
                        <td className="px-4 py-2 text-muted-foreground">{event}</td>
                        <td className="px-4 py-2">{country}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SECTION 6 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
            <h3 className="text-lg font-semibold mb-4">Recent Sessions</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-muted-foreground border-b border-border text-left">
                  <tr>
                    <th className="pb-3 font-medium">Time</th>
                    <th className="pb-3 font-medium">Session ID</th>
                    <th className="pb-3 font-medium hidden sm:table-cell">Domain</th>
                    <th className="pb-3 font-medium">Score</th>
                    <th className="pb-3 font-medium">Verdict</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {recentSessions.map((session, i) => (
                    <tr key={i} className="animate-in fade-in duration-300">
                      <td className="py-3 text-muted-foreground">{session.time}</td>
                      <td className="py-3 font-mono text-xs">{session.id}</td>
                      <td className="py-3 hidden sm:table-cell text-muted-foreground max-w-[100px] truncate">{session.domain}</td>
                      <td className="py-3">{session.score.toFixed(2)}</td>
                      <td className="py-3">
                        <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          session.verdict === 'HUMAN' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'
                        }`}>
                          {session.verdict}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Globe className="w-5 h-5 text-primary" /> Geographic Breakdown
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-muted-foreground border-b border-border text-left">
                  <tr>
                    <th className="pb-3 font-medium">Country</th>
                    <th className="pb-3 font-medium text-right">Sessions</th>
                    <th className="pb-3 font-medium text-right">Human Rate</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {GEO_DATA.map((geo, i) => {
                    const rate = parseInt(geo.humanRate);
                    return (
                      <tr key={i}>
                        <td className="py-3">{geo.country}</td>
                        <td className="py-3 text-right text-muted-foreground">{geo.sessions.toLocaleString()}</td>
                        <td className={`py-3 text-right font-medium ${
                          rate > 85 ? 'text-green-500' : rate >= 70 ? 'text-yellow-500' : 'text-red-500'
                        }`}>
                          {geo.humanRate}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-5 shadow-sm flex flex-col">
            <h3 className="text-lg font-semibold mb-4">Your Infrastructure (Managed)</h3>
            <div className="space-y-4 flex-1">
              {[
                { name: 'Edge Network (Cloudflare)', val: '50ms p99' },
                { name: 'Inference Engine', val: '4.2ms avg' },
                { name: 'Storage (ClickHouse)', val: 'Auto-scaled' },
                { name: 'Event Queue (Kafka)', val: '0 lag' },
                { name: 'Prometheus Metrics', val: 'Active' },
                { name: 'Failover', val: 'eu-west-1 standby' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <div className="w-2 h-2 rounded-full bg-green-500"></div>
                    {item.name}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{item.val}</span>
                    <span className="bg-secondary px-1.5 py-0.5 rounded text-[10px] uppercase border border-border">Managed</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 text-xs text-muted-foreground border-t border-border pt-4">
              You don't manage any of this.
            </div>
          </div>
        </div>

        {/* SECTION 7 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm hover:border-primary/50 transition-colors flex flex-col">
            <SiGoogleanalytics className="w-8 h-8 text-[#e37400] mb-4" />
            <h4 className="font-semibold mb-2">Google Analytics 4</h4>
            <p className="text-sm text-muted-foreground mb-4 flex-1">Enrich every GA4 event with human_score and verdict dimensions.</p>
            <button className="text-primary text-sm font-medium text-left hover:underline">Configure GA4 →</button>
          </div>
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm hover:border-primary/50 transition-colors flex flex-col">
            <SiWoocommerce className="w-8 h-8 text-[#96588a] mb-4" />
            <h4 className="font-semibold mb-2">WooCommerce</h4>
            <p className="text-sm text-muted-foreground mb-4 flex-1">Automatically block bot checkouts. Protect ad spend and conversion data.</p>
            <button className="text-primary text-sm font-medium text-left hover:underline">Install Extension →</button>
          </div>
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm hover:border-primary/50 transition-colors flex flex-col">
            <MessageSquare className="w-8 h-8 text-foreground mb-4" />
            <h4 className="font-semibold mb-2">Slack Alerts</h4>
            <p className="text-sm text-muted-foreground mb-4 flex-1">Get Slack notifications when bot traffic spikes above 20%.</p>
            <button className="text-primary text-sm font-medium text-left hover:underline">Connect Slack →</button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}