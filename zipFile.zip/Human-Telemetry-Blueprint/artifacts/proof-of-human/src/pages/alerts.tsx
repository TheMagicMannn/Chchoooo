import { useState } from "react";
import { AppLayout } from "@/components/app-layout";
import { ChevronDown, AlertTriangle, Shield, CheckCircle2 } from "lucide-react";

export default function Alerts() {
  const [activeTab, setActiveTab] = useState("Active Alerts");
  const tabs = ["Active Alerts", "CAPTCHA Rules", "Alert History"];

  const MVPBadge = () => <span className="text-xs font-mono bg-primary/20 text-primary px-1.5 py-0.5 rounded ml-2">MVP</span>;

  return (
    <AppLayout>
      <div className="p-6 md:p-10 max-w-6xl mx-auto w-full">
        <h1 className="text-3xl font-bold mb-6">Fraud Alerts & Escalation</h1>
        
        <div className="flex overflow-x-auto space-x-2 border-b border-border/40 mb-6 pb-px hide-scrollbar">
          {tabs.map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                activeTab === t
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t} {t !== "Active Alerts" && <MVPBadge />}
            </button>
          ))}
        </div>

        {activeTab === "Active Alerts" && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="bg-card border border-border p-4 rounded-xl shadow-sm">
                <div className="text-sm text-muted-foreground font-medium mb-1">Open Alerts</div>
                <div className="text-2xl font-bold text-red-500">4</div>
              </div>
              <div className="bg-card border border-border p-4 rounded-xl shadow-sm">
                <div className="text-sm text-muted-foreground font-medium mb-1">Resolved Today</div>
                <div className="text-2xl font-bold">12</div>
              </div>
              <div className="bg-card border border-border p-4 rounded-xl shadow-sm">
                <div className="text-sm text-muted-foreground font-medium mb-1">CAPTCHA Triggers</div>
                <div className="text-2xl font-bold text-yellow-500">89</div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold text-lg">Action Required</h3>
              
              <div className="bg-card border border-l-4 border-l-red-500 border-t-border border-r-border border-b-border p-4 rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bg-red-500/20 text-red-500 text-xs px-2 py-0.5 rounded font-bold uppercase tracking-wide">Critical</span>
                    <span className="text-sm text-muted-foreground">18 min ago</span>
                  </div>
                  <p className="font-medium">Bot cluster detected: 412 sessions sharing residential proxy fingerprint</p>
                  <p className="text-sm text-muted-foreground mt-1">Site: <span className="text-foreground">client-demo.com</span></p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button className="px-3 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors">Investigate</button>
                  <button className="px-3 py-1.5 bg-secondary text-secondary-foreground text-sm font-medium rounded-md hover:bg-secondary/80 transition-colors">Dismiss</button>
                </div>
              </div>

              <div className="bg-card border border-l-4 border-l-orange-500 border-t-border border-r-border border-b-border p-4 rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bg-orange-500/20 text-orange-500 text-xs px-2 py-0.5 rounded font-bold uppercase tracking-wide">High</span>
                    <span className="text-sm text-muted-foreground">1 hr ago</span>
                  </div>
                  <p className="font-medium">Bot rate spike: 34% above 7-day average for /checkout</p>
                  <p className="text-sm text-muted-foreground mt-1">Site: <span className="text-foreground">client-demo.com</span></p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button className="px-3 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors">Investigate</button>
                  <button className="px-3 py-1.5 bg-secondary text-secondary-foreground text-sm font-medium rounded-md hover:bg-secondary/80 transition-colors">Dismiss</button>
                </div>
              </div>

              <div className="bg-card border border-l-4 border-l-yellow-500 border-t-border border-r-border border-b-border p-4 rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bg-yellow-500/20 text-yellow-500 text-xs px-2 py-0.5 rounded font-bold uppercase tracking-wide">Medium</span>
                    <span className="text-sm text-muted-foreground">3 hr ago</span>
                  </div>
                  <p className="font-medium">CAPTCHA completion rate dropped to 23% (threshold: 60%)</p>
                  <p className="text-sm text-muted-foreground mt-1">Site: <span className="text-foreground">yourstore.com</span></p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button className="px-3 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors">Review</button>
                  <button className="px-3 py-1.5 bg-secondary text-secondary-foreground text-sm font-medium rounded-md hover:bg-secondary/80 transition-colors">Dismiss</button>
                </div>
              </div>

              <div className="bg-card border border-l-4 border-l-blue-500 border-t-border border-r-border border-b-border p-4 rounded-lg shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bg-blue-500/20 text-blue-500 text-xs px-2 py-0.5 rounded font-bold uppercase tracking-wide">Low</span>
                    <span className="text-sm text-muted-foreground">6 hr ago</span>
                  </div>
                  <p className="font-medium">New ASN detected: AS16509 (Amazon) — 340 sessions first-seen</p>
                  <p className="text-sm text-muted-foreground mt-1">Site: <span className="text-foreground">yourstore.com</span></p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button className="px-3 py-1.5 bg-secondary border border-border text-sm font-medium rounded-md hover:bg-secondary/80 transition-colors">Whitelist</button>
                  <button className="px-3 py-1.5 bg-primary text-primary-foreground text-sm font-medium rounded-md hover:bg-primary/90 transition-colors">Monitor</button>
                  <button className="px-3 py-1.5 bg-secondary text-secondary-foreground text-sm font-medium rounded-md hover:bg-secondary/80 transition-colors">Dismiss</button>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-border">
              <h3 className="font-semibold text-lg mb-4">Webhook Delivery Status</h3>
              <div className="bg-[#0d1117] rounded-lg p-4 font-mono text-xs overflow-x-auto">
                <div className="flex items-center gap-4 text-muted-foreground mb-1">
                  <span className="w-24">14:22:01</span>
                  <span className="flex-1 truncate">POST https://hooks.yourstore.com/poh-alerts</span>
                  <span className="text-green-400">200 OK</span>
                </div>
                <div className="flex items-center gap-4 text-muted-foreground mb-1">
                  <span className="w-24">14:15:33</span>
                  <span className="flex-1 truncate">POST https://hooks.yourstore.com/poh-alerts</span>
                  <span className="text-green-400">200 OK</span>
                </div>
                <div className="flex items-center gap-4 text-muted-foreground mb-1">
                  <span className="w-24">13:42:19</span>
                  <span className="flex-1 truncate">POST https://your-crm.com/webhooks/poh</span>
                  <span className="text-green-400">200 OK</span>
                </div>
                <div className="flex items-center gap-4 text-muted-foreground mb-1">
                  <span className="w-24">13:01:05</span>
                  <span className="flex-1 truncate">POST https://slack-webhook.example.com/...</span>
                  <span className="text-red-400">TIMEOUT</span>
                </div>
                <div className="flex items-center gap-4 text-muted-foreground">
                  <span className="w-24">12:55:12</span>
                  <span className="flex-1 truncate">POST https://hooks.yourstore.com/poh-alerts</span>
                  <span className="text-green-400">200 OK</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "CAPTCHA Rules" && (
          <div className="space-y-8 animate-in fade-in duration-300">
            <div>
              <h2 className="text-xl font-semibold">CAPTCHA Escalation Workflows</h2>
              <p className="text-muted-foreground mt-2 max-w-3xl">
                Define when to escalate a session to CAPTCHA challenge. Rules are evaluated in priority order.
              </p>
            </div>

            <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/20 text-muted-foreground">
                  <tr>
                    <th className="px-6 py-3 text-left font-medium">Priority</th>
                    <th className="px-6 py-3 text-left font-medium">Condition</th>
                    <th className="px-6 py-3 text-left font-medium">Action</th>
                    <th className="px-6 py-3 text-left font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3 text-muted-foreground">1</td>
                    <td className="px-6 py-3 font-mono text-xs">Score &lt; 0.3</td>
                    <td className="px-6 py-3 font-medium text-red-400">Block immediately</td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-4 bg-primary rounded-full relative"><div className="absolute right-1 top-0.5 w-3 h-3 bg-white rounded-full"></div></div>
                        <span className="text-xs">Active</span>
                      </div>
                    </td>
                  </tr>
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3 text-muted-foreground">2</td>
                    <td className="px-6 py-3 font-mono text-xs">Score 0.3–0.5 AND /checkout</td>
                    <td className="px-6 py-3 font-medium text-yellow-500">CAPTCHA challenge</td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-4 bg-primary rounded-full relative"><div className="absolute right-1 top-0.5 w-3 h-3 bg-white rounded-full"></div></div>
                        <span className="text-xs">Active</span>
                      </div>
                    </td>
                  </tr>
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3 text-muted-foreground">3</td>
                    <td className="px-6 py-3 font-mono text-xs">Score 0.3–0.5 AND other pages</td>
                    <td className="px-6 py-3 font-medium text-blue-400">Monitor + flag</td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-4 bg-primary rounded-full relative"><div className="absolute right-1 top-0.5 w-3 h-3 bg-white rounded-full"></div></div>
                        <span className="text-xs">Active</span>
                      </div>
                    </td>
                  </tr>
                  <tr className="hover:bg-muted/5">
                    <td className="px-6 py-3 text-muted-foreground">4</td>
                    <td className="px-6 py-3 font-mono text-xs">Cluster match (confidence &gt; 80%)</td>
                    <td className="px-6 py-3 font-medium text-red-400">Block + alert</td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-4 bg-primary rounded-full relative"><div className="absolute right-1 top-0.5 w-3 h-3 bg-white rounded-full"></div></div>
                        <span className="text-xs">Active</span>
                      </div>
                    </td>
                  </tr>
                  <tr className="hover:bg-muted/5 opacity-60">
                    <td className="px-6 py-3 text-muted-foreground">5</td>
                    <td className="px-6 py-3 font-mono text-xs">ASN = datacenter AND score &lt; 0.7</td>
                    <td className="px-6 py-3 font-medium text-yellow-500">CAPTCHA challenge</td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-4 bg-secondary rounded-full relative"><div className="absolute left-1 top-0.5 w-3 h-3 bg-muted-foreground rounded-full"></div></div>
                        <span className="text-xs">Paused</span>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
              <div className="px-6 py-3 border-t border-border bg-muted/10 text-center">
                <button className="text-sm font-medium text-primary hover:underline">+ Add New Rule</button>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-sm max-w-2xl">
              <h3 className="font-semibold text-lg mb-6 flex items-center gap-2"><Shield className="w-5 h-5 text-primary" /> CAPTCHA Provider Settings</h3>
              
              <div className="space-y-6">
                <div className="flex justify-between items-center pb-4 border-b border-border/50">
                  <div>
                    <div className="font-medium text-sm">Provider</div>
                    <div className="text-muted-foreground text-sm">Google reCAPTCHA v3</div>
                  </div>
                  <button className="text-sm text-primary font-medium px-3 py-1.5 bg-primary/10 rounded hover:bg-primary/20 transition-colors">Swap</button>
                </div>
                
                <div className="pb-4 border-b border-border/50">
                  <div className="font-medium text-sm mb-1">Fallback Provider</div>
                  <div className="text-muted-foreground text-sm">hCaptcha (used if primary provider times out)</div>
                </div>

                <div className="pb-4 border-b border-border/50">
                  <div className="flex justify-between mb-2">
                    <div className="font-medium text-sm">CAPTCHA Threshold Score</div>
                    <div className="text-sm font-mono bg-secondary px-2 py-0.5 rounded">0.50</div>
                  </div>
                  <div className="w-full h-2 bg-secondary rounded-full overflow-hidden mt-3 relative">
                    <div className="absolute left-0 top-0 h-full w-1/2 bg-gradient-to-r from-red-500 to-yellow-500"></div>
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground mt-2">
                    <span>Block (0.0)</span>
                    <span>Challenge (0.5)</span>
                    <span>Pass (1.0)</span>
                  </div>
                </div>

                <div>
                  <div className="font-medium text-sm mb-3">Challenge On Routes</div>
                  <div className="flex flex-wrap gap-2">
                    <span className="bg-primary/20 text-primary text-xs px-3 py-1 rounded-full font-medium border border-primary/20">/checkout</span>
                    <span className="bg-primary/20 text-primary text-xs px-3 py-1 rounded-full font-medium border border-primary/20">/login</span>
                    <span className="bg-primary/20 text-primary text-xs px-3 py-1 rounded-full font-medium border border-primary/20">/contact</span>
                    <span className="bg-primary/20 text-primary text-xs px-3 py-1 rounded-full font-medium border border-primary/20">/signup</span>
                    <span className="bg-secondary text-muted-foreground text-xs px-3 py-1 rounded-full font-medium border border-border cursor-pointer hover:bg-secondary/80">+ Add Route</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "Alert History" && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div className="flex flex-wrap gap-3 items-center p-4 bg-card border border-border rounded-xl shadow-sm">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary border border-border rounded-md text-sm cursor-pointer hover:bg-secondary/80">
                All severities <ChevronDown className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary border border-border rounded-md text-sm cursor-pointer hover:bg-secondary/80">
                All sites <ChevronDown className="w-4 h-4 text-muted-foreground" />
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary border border-border rounded-md text-sm cursor-pointer hover:bg-secondary/80">
                Last 7 days <ChevronDown className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted/20 text-muted-foreground border-b border-border/50">
                    <tr>
                      <th className="px-6 py-3 text-left font-medium whitespace-nowrap">Time</th>
                      <th className="px-6 py-3 text-left font-medium">Severity</th>
                      <th className="px-6 py-3 text-left font-medium">Message</th>
                      <th className="px-6 py-3 text-left font-medium">Site</th>
                      <th className="px-6 py-3 text-left font-medium">Action Taken</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {[
                      { time: "2024-01-15 14:22", sev: "CRITICAL", msg: "Bot cluster detected: 412 sessions", site: "client-demo.com", action: "Alert sent" },
                      { time: "2024-01-15 13:05", sev: "HIGH", msg: "Bot rate spike: 34% above average", site: "client-demo.com", action: "Alert sent" },
                      { time: "2024-01-15 11:12", sev: "MEDIUM", msg: "CAPTCHA completion rate dropped", site: "yourstore.com", action: "Review pending" },
                      { time: "2024-01-15 08:30", sev: "LOW", msg: "New ASN detected", site: "yourstore.com", action: "Manually dismissed" },
                      { time: "2024-01-14 22:15", sev: "CRITICAL", msg: "Velocity anomaly on /login", site: "client-demo.com", action: "Auto-blocked" },
                      { time: "2024-01-14 18:40", sev: "MEDIUM", msg: "High risk score cluster", site: "yourstore.com", action: "CAPTCHA triggered" },
                      { time: "2024-01-14 14:20", sev: "LOW", msg: "IP blocklist match (shared list)", site: "yourstore.com", action: "Auto-blocked" },
                      { time: "2024-01-14 09:11", sev: "HIGH", msg: "Credential stuffing attempt", site: "client-demo.com", action: "Rate limit applied" },
                      { time: "2024-01-13 21:05", sev: "MEDIUM", msg: "Suspicious user agent string", site: "client-demo.com", action: "Whitelisted" },
                      { time: "2024-01-13 16:30", sev: "LOW", msg: "Unusual geo-distribution", site: "yourstore.com", action: "Manually dismissed" },
                    ].map((row, i) => (
                      <tr key={i} className="hover:bg-muted/5 transition-colors">
                        <td className="px-6 py-3 font-mono text-xs text-muted-foreground whitespace-nowrap">{row.time}</td>
                        <td className="px-6 py-3">
                          <span className={`text-xs px-2 py-0.5 rounded font-bold uppercase tracking-wider ${
                            row.sev === 'CRITICAL' ? 'bg-red-500/20 text-red-500' :
                            row.sev === 'HIGH' ? 'bg-orange-500/20 text-orange-500' :
                            row.sev === 'MEDIUM' ? 'bg-yellow-500/20 text-yellow-500' :
                            'bg-blue-500/20 text-blue-500'
                          }`}>{row.sev}</span>
                        </td>
                        <td className="px-6 py-3 font-medium">{row.msg}</td>
                        <td className="px-6 py-3 text-muted-foreground">{row.site}</td>
                        <td className="px-6 py-3">
                          <span className="bg-secondary px-2 py-1 rounded text-xs">{row.action}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
